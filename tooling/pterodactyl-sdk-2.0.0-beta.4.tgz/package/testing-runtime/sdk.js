import { $ as Label, $t as clientSetServerDockerImageMutation, A as useSaveFileContent, B as EmptyDescription, Bt as notifyHttpError, D as useDeleteFiles, Dt as useExtensionCallback, Et as ExtensionContext, F as DropdownMenuItem, Gt as clientGetServerResourcesQueryKey, H as EmptyMedia, Ht as clientGetFileContentsQueryKey, I as DropdownMenuWithItems, It as useCurrentServerName, J as Checkbox, Jt as clientListFilesQueryKey, K as useAppForm, Kt as clientGetStartupConfigurationOptions, L as Tooltip$1, Lt as useCurrentServerPermissions$1, M as writeFileContentsInput, Mt as serverQueryFilters, N as updateListItems, Nt as serverQueryOptions$1, P as ContextDropdownMenu, Pt as useCurrentServer$1, Q as useFormContext, Qt as clientSendServerCommandMutation, R as Empty, Rt as useCurrentServerUuid$1, T as useCreateDirectory, U as EmptyTitle, Ut as clientGetServerLogsOptions, V as EmptyHeader, Vt as clientCreateServerBackupMutation, W as Dialog, Wt as clientGetServerResourcesOptions, X as Select, Xt as clientListServerBackupsQueryKey, Y as Switch, Yt as clientListServerBackupsOptions, Z as useFieldContext, Zt as clientSendPowerActionMutation, _n as __commonJSMin, a as useOpenLoginCheckpoint, an as SLOT_NAMES, b as serverFileContentQueryOptions$1, bt as useSocketConnected, c as useNavigationBlocker, ct as ButtonWithVariants, dt as Icon, en as clientUpdateStartupVariableMutation, et as NumberInput, f as createDirectoryInput, ft as cn, gn as EXTENSION_FORM_NAMES, ht as usePermissions, i as resolvePanelDestination, it as cardTitleClass, jt as useCurrentUser$1, k as useRenameFiles, kt as useSiteSettings$1, lt as Spinner, m as deleteFilesInput, mn as COMPONENT_NAMES, mt as hasPermission, n as useCurrentResource, nn as clientGetServerExtensionJobProgress, nt as TextInput, o as usePanelLocation, ot as SpinnerOverlay, q as Form, qt as clientGetStartupConfigurationQueryKey, r as PanelLink, rt as Portal, s as usePanelNavigate, st as Can, tn as clientGetExtensionJobProgress, tt as TextArea, x as serverFilesQueryOptions$1, xt as useSocketInstance, y as renameFilesInput, z as EmptyContent, zt as useUpdateCurrentServer } from "./resourceContext-CAzW3DX8.js";
import { c as httpErrorToHuman, d as isString$1, n as retryUnlessClientError, s as http, t as queryClient } from "./queryClient-D97HhWup.js";
import * as React$1 from "react";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { queryOptions, skipToken, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast, toast as toast$1 } from "sonner";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ArrowLeft, ChartNoAxesCombined, CheckCircle2, ChevronsLeft, ChevronsRight, File, Info, KeyRound, Network, Puzzle, RefreshCw, Server, Settings, ShieldAlert, Terminal, TriangleAlert, Users } from "lucide-react";
//#region ../../resources/scripts/plugins/useWebsocketEvent.ts
var useWebsocketEvent = (event, callback) => {
	const connected = useSocketConnected();
	const instance = useSocketInstance();
	const savedCallback = useRef(callback);
	useEffect(() => {
		savedCallback.current = callback;
	}, [callback]);
	return useEffect(() => {
		const eventListener = (data) => savedCallback.current(data);
		if (connected && instance) instance.addListener(event, eventListener);
		return () => {
			instance?.removeListener(event, eventListener);
		};
	}, [
		event,
		connected,
		instance
	]);
};
//#endregion
//#region ../../resources/scripts/components/server/events.ts
var SocketEvent = /* @__PURE__ */ function(SocketEvent) {
	SocketEvent["DAEMON_MESSAGE"] = "daemon message";
	SocketEvent["DAEMON_ERROR"] = "daemon error";
	SocketEvent["INSTALL_OUTPUT"] = "install output";
	SocketEvent["INSTALL_STARTED"] = "install started";
	SocketEvent["INSTALL_COMPLETED"] = "install completed";
	SocketEvent["CONSOLE_OUTPUT"] = "console output";
	SocketEvent["STATUS"] = "status";
	SocketEvent["STATS"] = "stats";
	SocketEvent["TRANSFER_LOGS"] = "transfer logs";
	SocketEvent["TRANSFER_STATUS"] = "transfer status";
	SocketEvent["BACKUP_COMPLETED"] = "backup completed";
	SocketEvent["BACKUP_RESTORE_COMPLETED"] = "backup restore completed";
	return SocketEvent;
}({});
//#endregion
//#region ../../resources/scripts/components/elements/NamedIcon.tsx
var bundled = new Map([
	["chart-no-axes-combined", ChartNoAxesCombined],
	["file", File],
	["key-round", KeyRound],
	["network", Network],
	["puzzle", Puzzle],
	["server", Server],
	["settings", Settings],
	["terminal", Terminal],
	["users", Users]
]);
var listeners$1 = /* @__PURE__ */ new Set();
var catalog;
var pending;
function loadCatalog() {
	pending ??= import("./iconCatalog-CCEB_yK2.js").catch(() => null).then((loaded) => {
		catalog = loaded;
		for (const listener of listeners$1) listener();
		return loaded;
	});
	return pending;
}
function subscribeCatalog(listener) {
	listeners$1.add(listener);
	loadCatalog();
	return () => {
		listeners$1.delete(listener);
	};
}
var subscribeNothing = () => () => {};
var getCatalog = () => catalog;
/** Every icon name this panel can render. */
async function loadIconNames() {
	return (await loadCatalog())?.iconNames ?? [...bundled.keys()];
}
/** The icon for a name: `undefined` while the icon set loads, `null` when the name is unknown. */
function useNamedIcon(name) {
	const immediate = bundled.get(name);
	const loaded = useSyncExternalStore(immediate ? subscribeNothing : subscribeCatalog, getCatalog);
	if (immediate) return immediate;
	return loaded === void 0 ? void 0 : loaded?.resolveIcon(name) ?? null;
}
function NamedIcon({ name, fallback = Puzzle, className, size = "1em", ...rest }) {
	const Resolved = useNamedIcon(name);
	if (Resolved === void 0) return /* @__PURE__ */ jsx("span", {
		"aria-hidden": true,
		className: cn("inline-block", className),
		style: {
			width: size,
			height: size
		}
	});
	return /* @__PURE__ */ jsx(Resolved ?? fallback, {
		className: cn("inline-block", className),
		size,
		...rest
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/ContentBox.tsx
var ContentBox = ({ title, borderColor, showLoadingOverlay, children, ...props }) => /* @__PURE__ */ jsxs("div", {
	...props,
	children: [title && /* @__PURE__ */ jsx("h2", {
		className: cn("font-header text-lg font-semibold tracking-normal text-foreground", "mb-4 px-4"),
		children: title
	}), /* @__PURE__ */ jsxs("div", {
		className: cn("bg-card p-4 rounded-sm shadow-lg relative", !!borderColor && "border-t-4"),
		children: [/* @__PURE__ */ jsx(SpinnerOverlay, { visible: showLoadingOverlay || false }), children]
	})]
});
//#endregion
//#region ../../resources/scripts/components/elements/ContentContainer.tsx
var ContentContainer = ({ className, ...props }) => /* @__PURE__ */ jsx("div", {
	className: cn("mx-4 max-w-panel xl:mx-auto", className),
	...props
});
ContentContainer.displayName = "ContentContainer";
//#endregion
//#region ../../resources/scripts/components/elements/PageContentBlock.tsx
var PageContentBlock = ({ title, className, children }) => {
	useEffect(() => {
		document.title = title || document.title;
	}, [title]);
	return /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(ContentContainer, {
		className: cn("my-4 sm:my-6", className),
		children
	}), /* @__PURE__ */ jsx(ContentContainer, {
		className: "mb-4",
		children: /* @__PURE__ */ jsxs("p", {
			className: "text-center text-muted-foreground text-xs",
			children: [
				/* @__PURE__ */ jsx("a", {
					rel: "noopener nofollow noreferrer",
					href: "https://pterodactyl.io",
					target: "_blank",
					className: "no-underline text-muted-foreground hover:text-muted-foreground",
					children: "Pterodactyl®"
				}),
				"\xA0© 2015 - ",
				/* @__PURE__ */ jsx("span", {
					suppressHydrationWarning: true,
					children: (/* @__PURE__ */ new Date()).getFullYear()
				})
			]
		})
	})] });
};
//#endregion
//#region ../../resources/scripts/components/elements/ServerContentBlock.tsx
var ServerContentBlock = ({ title, children, ...props }) => {
	const name = useCurrentServerName();
	return /* @__PURE__ */ jsx(PageContentBlock, {
		title: title ? `${name} | ${title}` : void 0,
		...props,
		children
	});
};
//#endregion
//#region ../../resources/scripts/components/elements/TitledGreyBox.tsx
var TitledGreyBox = ({ icon, title, children, className, contentClassName }) => /* @__PURE__ */ jsxs("div", {
	className: cn("rounded-sm shadow-md bg-card", className),
	children: [/* @__PURE__ */ jsx("div", {
		className: "bg-muted rounded-t-sm p-3 border-b border-border",
		children: isString$1(title) ? /* @__PURE__ */ jsxs("h2", {
			className: cardTitleClass,
			children: [icon && /* @__PURE__ */ jsx(Icon, {
				icon,
				className: "mr-2 text-muted-foreground"
			}), title]
		}) : title
	}), /* @__PURE__ */ jsx("div", {
		className: cn("p-3", contentClassName),
		children
	})]
});
//#endregion
//#region ../../resources/scripts/lib/clipboard.ts
/** Falls back to execCommand('copy') where the Clipboard API is unavailable, such as over plain HTTP. */
async function copyToClipboard(text) {
	if (window.isSecureContext && navigator.clipboard) try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {}
	const textarea = document.createElement("textarea");
	textarea.value = text;
	textarea.setAttribute("readonly", "");
	textarea.style.position = "fixed";
	textarea.style.top = "0";
	textarea.style.left = "0";
	textarea.style.opacity = "0";
	textarea.style.pointerEvents = "none";
	document.body.appendChild(textarea);
	textarea.focus();
	textarea.select();
	let succeeded = false;
	try {
		succeeded = document.execCommand("copy");
	} catch {
		succeeded = false;
	}
	document.body.removeChild(textarea);
	return succeeded;
}
//#endregion
//#region ../../resources/scripts/components/elements/CopyOnClick.tsx
var interactiveTypes = new Set([
	"a",
	"button",
	"input",
	"select",
	"textarea",
	ButtonWithVariants,
	ButtonWithVariants.Text,
	ButtonWithVariants.Danger,
	TextInput,
	TextArea
]);
var copyStatusMessage = (status, text, showInNotification) => {
	if (status === "failed") return "Unable to copy text to clipboard.";
	return showInNotification ? `Copied "${String(text)}" to clipboard.` : "Copied text to clipboard.";
};
/** Copies `text` when its single child is clicked; a non-interactive child becomes a focusable button. */
var CopyOnClick = ({ text, showInNotification = false, children }) => {
	const [status, setStatus] = useState(null);
	useEffect(() => {
		if (!status) return;
		const timeout = setTimeout(() => {
			setStatus(null);
		}, 2500);
		return () => {
			clearTimeout(timeout);
		};
	}, [status]);
	if (!React.isValidElement(children)) throw new Error("Component passed to <CopyOnClick/> must be a valid React element.");
	const element = React.Children.only(children);
	const copy = () => {
		copyToClipboard(String(text)).then((copied) => setStatus(copied ? "copied" : "failed"));
	};
	const interactive = interactiveTypes.has(element.type);
	const onKeyDown = (e) => {
		element.props.onKeyDown?.(e);
		if (!e.defaultPrevented && e.target === e.currentTarget && (e.key === "Enter" || e.key === " ")) {
			e.preventDefault();
			copy();
		}
	};
	const child = text ? React.cloneElement(element, {
		role: interactive ? element.props.role : element.props.role ?? "button",
		tabIndex: interactive ? element.props.tabIndex : element.props.tabIndex ?? 0,
		onKeyDown: interactive ? element.props.onKeyDown : onKeyDown,
		className: cn(element.props.className || "", "cursor-pointer"),
		onClick: (e) => {
			copy();
			element.props.onClick?.(e);
		}
	}) : element;
	return /* @__PURE__ */ jsxs(Fragment, { children: [status && /* @__PURE__ */ jsx(Portal, { children: /* @__PURE__ */ jsx("div", {
		className: "fixed z-50 bottom-0 right-0 m-4",
		children: /* @__PURE__ */ jsx("div", {
			role: "status",
			className: "rounded-md py-3 px-4 text-foreground bg-popover/95 shadow-sm",
			children: /* @__PURE__ */ jsx("p", { children: copyStatusMessage(status, text, showInNotification) })
		})
	}) }), child] });
};
//#endregion
//#region ../../resources/scripts/assets/images/not_found.svg
var not_found_default = "data:image/svg+xml,%3csvg%20id='a706cf1c-1654-439b-8fcf-310eb7aa0e00'%20data-name='Layer%201'%20xmlns='http://www.w3.org/2000/svg'%20width='1120.59226'%20height='777.91584'%20viewBox='0%200%201120.59226%20777.91584'%3e%3ctitle%3enot%20found%3c/title%3e%3ccircle%20cx='212.59226'%20cy='103'%20r='64'%20fill='%23ff6584'/%3e%3cpath%20d='M563.68016,404.16381c0,151.01141-89.77389,203.73895-200.51559,203.73895S162.649,555.17522,162.649,404.16381,363.16457,61.04208,363.16457,61.04208,563.68016,253.1524,563.68016,404.16381Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%23f2f2f2'/%3e%3cpolygon%20points='316.156%20523.761%20318.21%20397.378%20403.674%20241.024%20318.532%20377.552%20319.455%20320.725%20378.357%20207.605%20319.699%20305.687%20319.699%20305.687%20321.359%20203.481%20384.433%20113.423%20321.621%20187.409%20322.658%200%20316.138%20248.096%20316.674%20237.861%20252.547%20139.704%20315.646%20257.508%20309.671%20371.654%20309.493%20368.625%20235.565%20265.329%20309.269%20379.328%20308.522%20393.603%20308.388%20393.818%20308.449%20394.99%20293.29%20684.589%20313.544%20684.589%20315.974%20535.005%20389.496%20421.285%20316.156%20523.761'%20fill='%233f3d56'/%3e%3cpath%20d='M1160.29613,466.01367c0,123.61-73.4842,166.77-164.13156,166.77s-164.13156-43.16-164.13156-166.77S996.16457,185.15218,996.16457,185.15218,1160.29613,342.40364,1160.29613,466.01367Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%23f2f2f2'/%3e%3cpolygon%20points='950.482%20552.833%20952.162%20449.383%201022.119%20321.4%20952.426%20433.154%20953.182%20386.639%201001.396%20294.044%20953.382%20374.329%20953.382%20374.329%20954.741%20290.669%201006.369%20216.952%20954.954%20277.514%20955.804%20124.11%20950.467%20327.188%20950.906%20318.811%20898.414%20238.464%20950.064%20334.893%20945.173%20428.327%20945.027%20425.847%20884.514%20341.294%20944.844%20434.608%20944.232%20446.293%20944.123%20446.469%20944.173%20447.428%20931.764%20684.478%20948.343%20684.478%20950.332%20562.037%201010.514%20468.952%20950.482%20552.833'%20fill='%233f3d56'/%3e%3cellipse%20cx='554.59226'%20cy='680.47903'%20rx='554.59226'%20ry='28.03433'%20fill='%233f3d56'/%3e%3cellipse%20cx='892.44491'%20cy='726.79663'%20rx='94.98858'%20ry='4.80162'%20fill='%233f3d56'/%3e%3cellipse%20cx='548.71959'%20cy='773.11422'%20rx='94.98858'%20ry='4.80162'%20fill='%233f3d56'/%3e%3cellipse%20cx='287.94432'%20cy='734.27887'%20rx='217.01436'%20ry='10.96996'%20fill='%233f3d56'/%3e%3ccircle%20cx='97.08375'%20cy='566.26982'%20r='79'%20fill='%232f2e41'/%3e%3crect%20x='99.80546'%20y='689.02332'%20width='24'%20height='43'%20transform='translate(-31.32451%20-62.31008)%20rotate(0.67509)'%20fill='%232f2e41'/%3e%3crect%20x='147.80213'%20y='689.58887'%20width='24'%20height='43'%20transform='translate(-31.31452%20-62.87555)%20rotate(0.67509)'%20fill='%232f2e41'/%3e%3cellipse%20cx='119.54569'%20cy='732.61606'%20rx='7.5'%20ry='20'%20transform='translate(-654.1319%20782.47948)%20rotate(-89.32491)'%20fill='%232f2e41'/%3e%3cellipse%20cx='167.55414'%20cy='732.18168'%20rx='7.5'%20ry='20'%20transform='translate(-606.25475%20830.05533)%20rotate(-89.32491)'%20fill='%232f2e41'/%3e%3ccircle%20cx='99.31925'%20cy='546.29477'%20r='27'%20fill='%23fff'/%3e%3ccircle%20cx='99.31925'%20cy='546.29477'%20r='9'%20fill='%233f3d56'/%3e%3cpath%20d='M61.02588,552.94636c-6.04185-28.64075,14.68758-57.26483,46.30049-63.93367s62.13813,11.14292,68.18,39.78367-14.97834,38.93-46.59124,45.59886S67.06774,581.58712,61.02588,552.94636Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M257.29613,671.38411c0,55.07585-32.73985,74.3063-73.13,74.3063q-1.40351,0-2.80255-.0312c-1.87139-.04011-3.72494-.1292-5.55619-.254-36.45135-2.57979-64.77127-22.79937-64.77127-74.02113,0-53.00843,67.73872-119.89612,72.827-124.84633l.00892-.00889c.19608-.19159.29409-.28516.29409-.28516S257.29613,616.30827,257.29613,671.38411Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M181.50168,737.26482l26.747-37.37367-26.81386,41.4773-.07125,4.29076c-1.87139-.04011-3.72494-.1292-5.55619-.254l2.88282-55.10258-.0223-.42775.049-.0802.27179-5.20415-26.88076-41.5798,26.96539,37.67668.06244,1.105,2.17874-41.63324-23.0132-42.96551,23.29391,35.6583,2.26789-86.31419.00892-.294v.28516l-.37871,68.064,22.91079-26.98321-23.00435,32.84678-.60595,37.27566L204.18523,621.958l-21.4805,41.259-.33863,20.723,31.05561-49.79149-31.17146,57.023Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%233f3d56'/%3e%3ccircle%20cx='712.48505'%20cy='565.41532'%20r='79'%20fill='%232f2e41'/%3e%3crect%20x='741.77716'%20y='691.82355'%20width='24'%20height='43'%20transform='translate(-215.99457%20191.86399)%20rotate(-17.08345)'%20fill='%232f2e41'/%3e%3crect%20x='787.6593'%20y='677.72286'%20width='24'%20height='43'%20transform='matrix(0.95588,%20-0.29376,%200.29376,%200.95588,%20-209.82788,%20204.72037)'%20fill='%232f2e41'/%3e%3cellipse%20cx='767.887'%20cy='732.00275'%20rx='20'%20ry='7.5'%20transform='translate(-220.8593%20196.83312)%20rotate(-17.08345)'%20fill='%232f2e41'/%3e%3cellipse%20cx='813.47537'%20cy='716.94619'%20rx='20'%20ry='7.5'%20transform='translate(-214.42477%20209.56103)%20rotate(-17.08345)'%20fill='%232f2e41'/%3e%3ccircle%20cx='708.52153'%20cy='545.71023'%20r='27'%20fill='%23fff'/%3e%3ccircle%20cx='708.52153'%20cy='545.71023'%20r='9'%20fill='%233f3d56'/%3e%3cpath%20d='M657.35526,578.74316c-14.48957-25.43323-3.47841-59.016,24.59412-75.0092s62.57592-8.34055,77.06549,17.09268-2.39072,41.6435-30.46325,57.63671S671.84483,604.17639,657.35526,578.74316Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M611.29613,661.29875c0,50.55711-30.05368,68.20979-67.13,68.20979q-1.28835,0-2.57261-.02864c-1.71785-.03682-3.41933-.1186-5.10033-.23313-33.46068-2.36813-59.45707-20.92878-59.45707-67.948,0-48.65932,62.18106-110.05916,66.85186-114.60322l.00819-.00817c.18-.17587.27-.26177.27-.26177S611.29613,610.74164,611.29613,661.29875Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M541.72029,721.77424l24.55253-34.30732-24.6139,38.07426-.0654,3.93872c-1.71785-.03682-3.41933-.1186-5.10033-.23313l2.6463-50.58165-.02047-.39266.045-.07361.24949-4.77718-24.67531-38.16836,24.753,34.58547.05731,1.01433,2-38.21741-21.12507-39.44039L541.80616,625.928l2.08182-79.23247.00819-.26994v.26177l-.34764,62.47962,21.031-24.76934-21.11693,30.15184-.55624,34.21735,19.63634-32.839-19.71812,37.87389-.31085,19.0228,28.50763-45.70631-28.614,52.34448Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%233f3d56'/%3e%3cpath%20d='M875.29613,682.38411c0,55.07585-32.73985,74.3063-73.13,74.3063q-1.4035,0-2.80255-.0312c-1.87139-.04011-3.72494-.1292-5.55619-.254-36.45135-2.57979-64.77127-22.79937-64.77127-74.02113,0-53.00843,67.73872-119.89612,72.827-124.84633l.00892-.00889c.19608-.19159.29409-.28516.29409-.28516S875.29613,627.30827,875.29613,682.38411Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%230967d3'/%3e%3cpath%20d='M799.50168,748.26482l26.747-37.37367-26.81386,41.4773-.07125,4.29076c-1.87139-.04011-3.72494-.1292-5.55619-.254l2.88282-55.10258-.0223-.42775.049-.0802.27179-5.20415L770.108,654.01076l26.96539,37.67668.06244,1.105,2.17874-41.63324-23.0132-42.96551,23.29391,35.6583,2.26789-86.31419.00892-.294v.28516l-.37871,68.064,22.91079-26.98321-23.00435,32.84678-.606,37.27566L822.18523,632.958l-21.4805,41.259-.33863,20.723,31.05561-49.79149-31.17146,57.023Z'%20transform='translate(-39.70387%20-61.04208)'%20fill='%233f3d56'/%3e%3cellipse%20cx='721.51694'%20cy='656.82212'%20rx='12.40027'%20ry='39.5'%20transform='translate(-220.83517%20966.22323)%20rotate(-64.62574)'%20fill='%232f2e41'/%3e%3cellipse%20cx='112.51694'%20cy='651.82212'%20rx='12.40027'%20ry='39.5'%20transform='translate(-574.07936%20452.71367)%20rotate(-68.15829)'%20fill='%232f2e41'/%3e%3c/svg%3e";
//#endregion
//#region ../../resources/scripts/assets/images/server_error.svg
var server_error_default = "data:image/svg+xml,%3csvg%20id='aa03ddf9-f8f2-4819-a4ce-be9b0a220741'%20data-name='Layer%201'%20xmlns='http://www.w3.org/2000/svg'%20width='1119.60911'%20height='699'%20viewBox='0%200%201119.60911%20699'%3e%3ctitle%3eserver%20down%3c/title%3e%3ccircle%20cx='292.60911'%20cy='213'%20r='213'%20fill='%23f2f2f2'/%3e%3cpath%20d='M31.39089,151.64237c0,77.49789,48.6181,140.20819,108.70073,140.20819'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpath%20d='M140.09162,291.85056c0-78.36865,54.255-141.78356,121.30372-141.78356'%20transform='translate(-31.39089%20-100.5)'%20fill='%230967d3'/%3e%3cpath%20d='M70.77521,158.66768c0,73.61476,31.00285,133.18288,69.31641,133.18288'%20transform='translate(-31.39089%20-100.5)'%20fill='%230967d3'/%3e%3cpath%20d='M140.09162,291.85056c0-100.13772,62.7103-181.16788,140.20819-181.16788'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpath%20d='M117.22379,292.83905s15.41555-.47479,20.06141-3.783,23.713-7.2585,24.86553-1.95278,23.16671,26.38821,5.76263,26.5286-40.43935-2.711-45.07627-5.53549S117.22379,292.83905,117.22379,292.83905Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%23a8a8a8'/%3e%3cpath%20d='M168.224,311.78489c-17.40408.14042-40.43933-2.71094-45.07626-5.53548-3.53126-2.151-4.93843-9.86945-5.40926-13.43043-.32607.014-.51463.02-.51463.02s.97638,12.43276,5.61331,15.2573,27.67217,5.67589,45.07626,5.53547c5.02386-.04052,6.7592-1.82793,6.66391-4.47526C173.87935,310.756,171.96329,311.75474,168.224,311.78489Z'%20transform='translate(-31.39089%20-100.5)'%20opacity='0.2'/%3e%3cellipse%20cx='198.60911'%20cy='424.5'%20rx='187'%20ry='25.43993'%20fill='%233f3d56'/%3e%3cellipse%20cx='198.60911'%20cy='424.5'%20rx='157'%20ry='21.35866'%20opacity='0.1'/%3e%3cellipse%20cx='836.60911'%20cy='660.5'%20rx='283'%20ry='38.5'%20fill='%233f3d56'/%3e%3cellipse%20cx='310.60911'%20cy='645.5'%20rx='170'%20ry='23.12721'%20fill='%233f3d56'/%3e%3cpath%20d='M494,726.5c90,23,263-30,282-90'%20transform='translate(-31.39089%20-100.5)'%20fill='none'%20stroke='%232f2e41'%20stroke-miterlimit='10'%20stroke-width='2'/%3e%3cpath%20d='M341,359.5s130-36,138,80-107,149-17,172'%20transform='translate(-31.39089%20-100.5)'%20fill='none'%20stroke='%232f2e41'%20stroke-miterlimit='10'%20stroke-width='2'/%3e%3cpath%20d='M215.40233,637.78332s39.0723-10.82,41.47675,24.04449-32.15951,44.78287-5.10946,51.69566'%20transform='translate(-31.39089%20-100.5)'%20fill='none'%20stroke='%232f2e41'%20stroke-miterlimit='10'%20stroke-width='2'/%3e%3cpath%20d='M810.09554,663.73988,802.218,714.03505s-38.78182,20.60284-11.51335,21.20881,155.73324,0,155.73324,0,24.84461,0-14.54318-21.81478l-7.87756-52.719Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpath%20d='M785.21906,734.69812c6.193-5.51039,16.9989-11.252,16.9989-11.252l7.87756-50.2952,113.9216.10717,7.87756,49.582c9.185,5.08711,14.8749,8.987,18.20362,11.97818,5.05882-1.15422,10.58716-5.44353-18.20362-21.38921l-7.87756-52.719-113.9216,3.02983L802.218,714.03506S769.62985,731.34968,785.21906,734.69812Z'%20transform='translate(-31.39089%20-100.5)'%20opacity='0.1'/%3e%3crect%20x='578.43291'%20y='212.68859'%20width='513.25314'%20height='357.51989'%20rx='18.04568'%20fill='%232f2e41'/%3e%3crect%20x='595.70294'%20y='231.77652'%20width='478.71308'%20height='267.83694'%20fill='%233f3d56'/%3e%3ccircle%20cx='835.05948'%20cy='223.29299'%20r='3.02983'%20fill='%23f2f2f2'/%3e%3cpath%20d='M1123.07694,621.32226V652.6628a18.04341,18.04341,0,0,1-18.04568,18.04568H627.86949A18.04341,18.04341,0,0,1,609.8238,652.6628V621.32226Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpolygon%20points='968.978%20667.466%20968.978%20673.526%20642.968%20673.526%20642.968%20668.678%20643.417%20667.466%20651.452%20645.651%20962.312%20645.651%20968.978%20667.466'%20fill='%232f2e41'/%3e%3cpath%20d='M1125.828,762.03359c-.59383,2.539-2.83591,5.21743-7.90178,7.75032-18.179,9.08949-55.1429-2.42386-55.1429-2.42386s-28.4804-4.84773-28.4804-17.573a22.72457,22.72457,0,0,1,2.49658-1.48459c7.64294-4.04351,32.98449-14.02122,77.9177.42248a18.73921,18.73921,0,0,1,8.54106,5.59715C1125.07908,756.45353,1126.50669,759.15715,1125.828,762.03359Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%232f2e41'/%3e%3cpath%20d='M1125.828,762.03359c-22.251,8.526-42.0843,9.1622-62.43871-4.975-10.26507-7.12617-19.59089-8.88955-26.58979-8.75618,7.64294-4.04351,32.98449-14.02122,77.9177.42248a18.73921,18.73921,0,0,1,8.54106,5.59715C1125.07908,756.45353,1126.50669,759.15715,1125.828,762.03359Z'%20transform='translate(-31.39089%20-100.5)'%20opacity='0.1'/%3e%3cellipse%20cx='1066.53846'%20cy='654.13477'%20rx='7.87756'%20ry='2.42386'%20fill='%23f2f2f2'/%3e%3ccircle%20cx='835.05948'%20cy='545.66686'%20r='11.51335'%20fill='%23f2f2f2'/%3e%3cpolygon%20points='968.978%20667.466%20968.978%20673.526%20642.968%20673.526%20642.968%20668.678%20643.417%20667.466%20968.978%20667.466'%20opacity='0.1'/%3e%3crect%20x='108.60911'%20y='159'%20width='208'%20height='242'%20fill='%232f2e41'/%3e%3crect%20x='87.60911'%20y='135'%20width='250'%20height='86'%20fill='%233f3d56'/%3e%3crect%20x='87.60911'%20y='237'%20width='250'%20height='86'%20fill='%233f3d56'/%3e%3crect%20x='87.60911'%20y='339'%20width='250'%20height='86'%20fill='%233f3d56'/%3e%3crect%20x='271.60911'%20y='150'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.4'/%3e%3crect%20x='294.60911'%20y='150'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.8'/%3e%3crect%20x='317.60911'%20y='150'%20width='16'%20height='16'%20fill='%230967d3'/%3e%3crect%20x='271.60911'%20y='251'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.4'/%3e%3crect%20x='294.60911'%20y='251'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.8'/%3e%3crect%20x='317.60911'%20y='251'%20width='16'%20height='16'%20fill='%230967d3'/%3e%3crect%20x='271.60911'%20y='352'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.4'/%3e%3crect%20x='294.60911'%20y='352'%20width='16'%20height='16'%20fill='%230967d3'%20opacity='0.8'/%3e%3crect%20x='317.60911'%20y='352'%20width='16'%20height='16'%20fill='%230967d3'/%3e%3ccircle%20cx='316.60911'%20cy='538'%20r='79'%20fill='%232f2e41'/%3e%3crect%20x='280.60911'%20y='600'%20width='24'%20height='43'%20fill='%232f2e41'/%3e%3crect%20x='328.60911'%20y='600'%20width='24'%20height='43'%20fill='%232f2e41'/%3e%3cellipse%20cx='300.60911'%20cy='643.5'%20rx='20'%20ry='7.5'%20fill='%232f2e41'/%3e%3cellipse%20cx='348.60911'%20cy='642.5'%20rx='20'%20ry='7.5'%20fill='%232f2e41'/%3e%3ccircle%20cx='318.60911'%20cy='518'%20r='27'%20fill='%23fff'/%3e%3ccircle%20cx='318.60911'%20cy='518'%20r='9'%20fill='%233f3d56'/%3e%3cpath%20d='M271.36733,565.03228c-6.37889-28.56758,14.01185-57.43392,45.544-64.47477s62.2651,10.41,68.644,38.9776-14.51861,39.10379-46.05075,46.14464S277.74622,593.59986,271.36733,565.03228Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%230967d3'/%3e%3cellipse%20cx='417.21511'%20cy='611.34365'%20rx='39.5'%20ry='12.40027'%20transform='translate(-238.28665%20112.98044)%20rotate(-23.17116)'%20fill='%232f2e41'/%3e%3cellipse%20cx='269.21511'%20cy='664.34365'%20rx='39.5'%20ry='12.40027'%20transform='translate(-271.07969%2059.02084)%20rotate(-23.17116)'%20fill='%232f2e41'/%3e%3cpath%20d='M394,661.5c0,7.732-19.90861,23-42,23s-43-14.268-43-22,20.90861-6,43-6S394,653.768,394,661.5Z'%20transform='translate(-31.39089%20-100.5)'%20fill='%23fff'/%3e%3c/svg%3e";
//#endregion
//#region ../../resources/scripts/components/elements/ScreenBlock.tsx
var ActionButton = ({ className, ...props }) => /* @__PURE__ */ jsx(ButtonWithVariants, {
	className: cn("rounded-full w-8 h-8 flex items-center justify-center p-0", className),
	...props
});
var ScreenBlock = ({ title, image, message, onBack, onRetry }) => /* @__PURE__ */ jsx(PageContentBlock, { children: /* @__PURE__ */ jsx("div", {
	className: "flex justify-center",
	children: /* @__PURE__ */ jsxs("div", {
		className: "w-full sm:w-3/4 md:w-1/2 p-12 md:p-20 bg-card rounded-lg shadow-lg text-center relative",
		children: [
			(onBack ?? onRetry) && /* @__PURE__ */ jsx("div", {
				className: "absolute left-0 top-0 ml-4 mt-4",
				children: /* @__PURE__ */ jsx(ActionButton, {
					"aria-label": onRetry ? "Retry" : "Go back",
					title: onRetry ? "Retry" : "Go back",
					onClick: () => (onRetry ?? onBack)?.(),
					className: onRetry ? "hover:animate-[spin_2s_linear_infinite]" : void 0,
					children: /* @__PURE__ */ jsx(Icon, { icon: onRetry ? RefreshCw : ArrowLeft })
				})
			}),
			/* @__PURE__ */ jsx("img", {
				src: image,
				alt: "",
				className: "w-2/3 h-auto select-none mx-auto"
			}),
			/* @__PURE__ */ jsx("h2", {
				className: "mt-10 text-foreground font-bold text-4xl",
				children: title
			}),
			/* @__PURE__ */ jsx("p", {
				className: "text-sm text-muted-foreground mt-2",
				children: message
			})
		]
	})
}) });
var ServerError = ({ title = "Something went wrong", message, onBack, onRetry }) => onRetry ? /* @__PURE__ */ jsx(ScreenBlock, {
	title,
	image: server_error_default,
	message,
	onRetry
}) : /* @__PURE__ */ jsx(ScreenBlock, {
	title,
	image: server_error_default,
	message,
	onBack
});
var NotFound = ({ title, message, onBack }) => /* @__PURE__ */ jsx(ScreenBlock, {
	title: title || "404",
	image: not_found_default,
	message: message || "The requested resource was not found.",
	onBack
});
//#endregion
//#region ../../resources/scripts/components/elements/alert/Alert.tsx
var alertConfig = {
	success: {
		icon: CheckCircle2,
		className: "border-success bg-success/15",
		iconClassName: "text-success"
	},
	info: {
		icon: Info,
		className: "border-accent bg-accent/10",
		iconClassName: "text-accent"
	},
	warning: {
		icon: TriangleAlert,
		className: "border-warning bg-warning/15",
		iconClassName: "text-warning"
	},
	danger: {
		icon: ShieldAlert,
		className: "border-destructive bg-destructive/15",
		iconClassName: "text-destructive"
	}
};
function Alert({ type, title, className, children }) {
	const config = alertConfig[type];
	const AlertIcon = config.icon;
	return /* @__PURE__ */ jsxs("div", {
		role: "alert",
		className: cn("flex items-start rounded-sm border border-l-4 px-4 py-3 text-foreground shadow-sm", config.className, className),
		children: [/* @__PURE__ */ jsx(AlertIcon, {
			"aria-hidden": true,
			className: cn("mr-3 mt-0.5 h-5 w-5 shrink-0", config.iconClassName)
		}), /* @__PURE__ */ jsxs("div", {
			className: "min-w-0 flex-1 text-sm leading-relaxed",
			children: [title && /* @__PURE__ */ jsx("p", {
				className: "mb-1 font-semibold text-foreground",
				children: title
			}), /* @__PURE__ */ jsx("div", { children })]
		})]
	});
}
//#endregion
//#region ../../node_modules/@tanstack/table-core/build/lib/index.mjs
/**
* table-core
*
* Copyright (c) TanStack
*
* This source code is licensed under the MIT license found in the
* LICENSE.md file in the root directory of this source tree.
*
* @license MIT
*/
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
function makeStateUpdater(key, instance) {
	return (updater) => {
		instance.setState((old) => {
			return {
				...old,
				[key]: functionalUpdate(updater, old[key])
			};
		});
	};
}
function isFunction(d) {
	return d instanceof Function;
}
function isNumberArray(d) {
	return Array.isArray(d) && d.every((val) => typeof val === "number");
}
function flattenBy(arr, getChildren) {
	const flat = [];
	const recurse = (subArr) => {
		subArr.forEach((item) => {
			flat.push(item);
			const children = getChildren(item);
			if (children != null && children.length) recurse(children);
		});
	};
	recurse(arr);
	return flat;
}
function memo$1(getDeps, fn, opts) {
	let deps = [];
	let result;
	return (depArgs) => {
		let depTime;
		if (opts.key && opts.debug) depTime = Date.now();
		const newDeps = getDeps(depArgs);
		if (!(newDeps.length !== deps.length || newDeps.some((dep, index) => deps[index] !== dep))) return result;
		deps = newDeps;
		let resultTime;
		if (opts.key && opts.debug) resultTime = Date.now();
		result = fn(...newDeps);
		opts == null || opts.onChange == null || opts.onChange(result);
		if (opts.key && opts.debug) {
			if (opts != null && opts.debug()) {
				const depEndTime = Math.round((Date.now() - depTime) * 100) / 100;
				const resultEndTime = Math.round((Date.now() - resultTime) * 100) / 100;
				const resultFpsPercentage = resultEndTime / 16;
				const pad = (str, num) => {
					str = String(str);
					while (str.length < num) str = " " + str;
					return str;
				};
				console.info(`%c⏱ ${pad(resultEndTime, 5)} /${pad(depEndTime, 5)} ms`, `
            font-size: .6rem;
            font-weight: bold;
            color: hsl(${Math.max(0, Math.min(120 - 120 * resultFpsPercentage, 120))}deg 100% 31%);`, opts == null ? void 0 : opts.key);
			}
		}
		return result;
	};
}
function getMemoOptions(tableOptions, debugLevel, key, onChange) {
	return {
		debug: () => {
			var _tableOptions$debugAl;
			return (_tableOptions$debugAl = tableOptions == null ? void 0 : tableOptions.debugAll) != null ? _tableOptions$debugAl : tableOptions[debugLevel];
		},
		key: process.env.NODE_ENV === "development" && key,
		onChange
	};
}
function createCell(table, row, column, columnId) {
	const getRenderValue = () => {
		var _cell$getValue;
		return (_cell$getValue = cell.getValue()) != null ? _cell$getValue : table.options.renderFallbackValue;
	};
	const cell = {
		id: `${row.id}_${column.id}`,
		row,
		column,
		getValue: () => row.getValue(columnId),
		renderValue: getRenderValue,
		getContext: memo$1(() => [
			table,
			column,
			row,
			cell
		], (table, column, row, cell) => ({
			table,
			column,
			row,
			cell,
			getValue: cell.getValue,
			renderValue: cell.renderValue
		}), getMemoOptions(table.options, "debugCells", "cell.getContext"))
	};
	table._features.forEach((feature) => {
		feature.createCell == null || feature.createCell(cell, column, row, table);
	}, {});
	return cell;
}
function createColumn(table, columnDef, depth, parent) {
	var _ref, _resolvedColumnDef$id;
	const resolvedColumnDef = {
		...table._getDefaultColumnDef(),
		...columnDef
	};
	const accessorKey = resolvedColumnDef.accessorKey;
	let id = (_ref = (_resolvedColumnDef$id = resolvedColumnDef.id) != null ? _resolvedColumnDef$id : accessorKey ? typeof String.prototype.replaceAll === "function" ? accessorKey.replaceAll(".", "_") : accessorKey.replace(/\./g, "_") : void 0) != null ? _ref : typeof resolvedColumnDef.header === "string" ? resolvedColumnDef.header : void 0;
	let accessorFn;
	if (resolvedColumnDef.accessorFn) accessorFn = resolvedColumnDef.accessorFn;
	else if (accessorKey) if (accessorKey.includes(".")) accessorFn = (originalRow) => {
		let result = originalRow;
		for (const key of accessorKey.split(".")) {
			var _result;
			result = (_result = result) == null ? void 0 : _result[key];
			if (process.env.NODE_ENV !== "production" && result === void 0) console.warn(`"${key}" in deeply nested key "${accessorKey}" returned undefined.`);
		}
		return result;
	};
	else accessorFn = (originalRow) => originalRow[resolvedColumnDef.accessorKey];
	if (!id) {
		if (process.env.NODE_ENV !== "production") throw new Error(resolvedColumnDef.accessorFn ? `Columns require an id when using an accessorFn` : `Columns require an id when using a non-string header`);
		throw new Error();
	}
	let column = {
		id: `${String(id)}`,
		accessorFn,
		parent,
		depth,
		columnDef: resolvedColumnDef,
		columns: [],
		getFlatColumns: memo$1(() => [true], () => {
			var _column$columns;
			return [column, ...(_column$columns = column.columns) == null ? void 0 : _column$columns.flatMap((d) => d.getFlatColumns())];
		}, getMemoOptions(table.options, "debugColumns", "column.getFlatColumns")),
		getLeafColumns: memo$1(() => [table._getOrderColumnsFn()], (orderColumns) => {
			var _column$columns2;
			if ((_column$columns2 = column.columns) != null && _column$columns2.length) return orderColumns(column.columns.flatMap((column) => column.getLeafColumns()));
			return [column];
		}, getMemoOptions(table.options, "debugColumns", "column.getLeafColumns"))
	};
	for (const feature of table._features) feature.createColumn == null || feature.createColumn(column, table);
	return column;
}
var debug = "debugHeaders";
function createHeader(table, column, options) {
	var _options$id;
	let header = {
		id: (_options$id = options.id) != null ? _options$id : column.id,
		column,
		index: options.index,
		isPlaceholder: !!options.isPlaceholder,
		placeholderId: options.placeholderId,
		depth: options.depth,
		subHeaders: [],
		colSpan: 0,
		rowSpan: 0,
		headerGroup: null,
		getLeafHeaders: () => {
			const leafHeaders = [];
			const recurseHeader = (h) => {
				if (h.subHeaders && h.subHeaders.length) h.subHeaders.map(recurseHeader);
				leafHeaders.push(h);
			};
			recurseHeader(header);
			return leafHeaders;
		},
		getContext: () => ({
			table,
			header,
			column
		})
	};
	table._features.forEach((feature) => {
		feature.createHeader == null || feature.createHeader(header, table);
	});
	return header;
}
var Headers = { createTable: (table) => {
	table.getHeaderGroups = memo$1(() => [
		table.getAllColumns(),
		table.getVisibleLeafColumns(),
		table.getState().columnPinning.left,
		table.getState().columnPinning.right
	], (allColumns, leafColumns, left, right) => {
		var _left$map$filter, _right$map$filter;
		const leftColumns = (_left$map$filter = left == null ? void 0 : left.map((columnId) => leafColumns.find((d) => d.id === columnId)).filter(Boolean)) != null ? _left$map$filter : [];
		const rightColumns = (_right$map$filter = right == null ? void 0 : right.map((columnId) => leafColumns.find((d) => d.id === columnId)).filter(Boolean)) != null ? _right$map$filter : [];
		const centerColumns = leafColumns.filter((column) => !(left != null && left.includes(column.id)) && !(right != null && right.includes(column.id)));
		return buildHeaderGroups(allColumns, [
			...leftColumns,
			...centerColumns,
			...rightColumns
		], table);
	}, getMemoOptions(table.options, debug, "getHeaderGroups"));
	table.getCenterHeaderGroups = memo$1(() => [
		table.getAllColumns(),
		table.getVisibleLeafColumns(),
		table.getState().columnPinning.left,
		table.getState().columnPinning.right
	], (allColumns, leafColumns, left, right) => {
		leafColumns = leafColumns.filter((column) => !(left != null && left.includes(column.id)) && !(right != null && right.includes(column.id)));
		return buildHeaderGroups(allColumns, leafColumns, table, "center");
	}, getMemoOptions(table.options, debug, "getCenterHeaderGroups"));
	table.getLeftHeaderGroups = memo$1(() => [
		table.getAllColumns(),
		table.getVisibleLeafColumns(),
		table.getState().columnPinning.left
	], (allColumns, leafColumns, left) => {
		var _left$map$filter2;
		return buildHeaderGroups(allColumns, (_left$map$filter2 = left == null ? void 0 : left.map((columnId) => leafColumns.find((d) => d.id === columnId)).filter(Boolean)) != null ? _left$map$filter2 : [], table, "left");
	}, getMemoOptions(table.options, debug, "getLeftHeaderGroups"));
	table.getRightHeaderGroups = memo$1(() => [
		table.getAllColumns(),
		table.getVisibleLeafColumns(),
		table.getState().columnPinning.right
	], (allColumns, leafColumns, right) => {
		var _right$map$filter2;
		return buildHeaderGroups(allColumns, (_right$map$filter2 = right == null ? void 0 : right.map((columnId) => leafColumns.find((d) => d.id === columnId)).filter(Boolean)) != null ? _right$map$filter2 : [], table, "right");
	}, getMemoOptions(table.options, debug, "getRightHeaderGroups"));
	table.getFooterGroups = memo$1(() => [table.getHeaderGroups()], (headerGroups) => {
		return [...headerGroups].reverse();
	}, getMemoOptions(table.options, debug, "getFooterGroups"));
	table.getLeftFooterGroups = memo$1(() => [table.getLeftHeaderGroups()], (headerGroups) => {
		return [...headerGroups].reverse();
	}, getMemoOptions(table.options, debug, "getLeftFooterGroups"));
	table.getCenterFooterGroups = memo$1(() => [table.getCenterHeaderGroups()], (headerGroups) => {
		return [...headerGroups].reverse();
	}, getMemoOptions(table.options, debug, "getCenterFooterGroups"));
	table.getRightFooterGroups = memo$1(() => [table.getRightHeaderGroups()], (headerGroups) => {
		return [...headerGroups].reverse();
	}, getMemoOptions(table.options, debug, "getRightFooterGroups"));
	table.getFlatHeaders = memo$1(() => [table.getHeaderGroups()], (headerGroups) => {
		return headerGroups.map((headerGroup) => {
			return headerGroup.headers;
		}).flat();
	}, getMemoOptions(table.options, debug, "getFlatHeaders"));
	table.getLeftFlatHeaders = memo$1(() => [table.getLeftHeaderGroups()], (left) => {
		return left.map((headerGroup) => {
			return headerGroup.headers;
		}).flat();
	}, getMemoOptions(table.options, debug, "getLeftFlatHeaders"));
	table.getCenterFlatHeaders = memo$1(() => [table.getCenterHeaderGroups()], (left) => {
		return left.map((headerGroup) => {
			return headerGroup.headers;
		}).flat();
	}, getMemoOptions(table.options, debug, "getCenterFlatHeaders"));
	table.getRightFlatHeaders = memo$1(() => [table.getRightHeaderGroups()], (left) => {
		return left.map((headerGroup) => {
			return headerGroup.headers;
		}).flat();
	}, getMemoOptions(table.options, debug, "getRightFlatHeaders"));
	table.getCenterLeafHeaders = memo$1(() => [table.getCenterFlatHeaders()], (flatHeaders) => {
		return flatHeaders.filter((header) => {
			var _header$subHeaders;
			return !((_header$subHeaders = header.subHeaders) != null && _header$subHeaders.length);
		});
	}, getMemoOptions(table.options, debug, "getCenterLeafHeaders"));
	table.getLeftLeafHeaders = memo$1(() => [table.getLeftFlatHeaders()], (flatHeaders) => {
		return flatHeaders.filter((header) => {
			var _header$subHeaders2;
			return !((_header$subHeaders2 = header.subHeaders) != null && _header$subHeaders2.length);
		});
	}, getMemoOptions(table.options, debug, "getLeftLeafHeaders"));
	table.getRightLeafHeaders = memo$1(() => [table.getRightFlatHeaders()], (flatHeaders) => {
		return flatHeaders.filter((header) => {
			var _header$subHeaders3;
			return !((_header$subHeaders3 = header.subHeaders) != null && _header$subHeaders3.length);
		});
	}, getMemoOptions(table.options, debug, "getRightLeafHeaders"));
	table.getLeafHeaders = memo$1(() => [
		table.getLeftHeaderGroups(),
		table.getCenterHeaderGroups(),
		table.getRightHeaderGroups()
	], (left, center, right) => {
		var _left$0$headers, _left$, _center$0$headers, _center$, _right$0$headers, _right$;
		return [
			...(_left$0$headers = (_left$ = left[0]) == null ? void 0 : _left$.headers) != null ? _left$0$headers : [],
			...(_center$0$headers = (_center$ = center[0]) == null ? void 0 : _center$.headers) != null ? _center$0$headers : [],
			...(_right$0$headers = (_right$ = right[0]) == null ? void 0 : _right$.headers) != null ? _right$0$headers : []
		].map((header) => {
			return header.getLeafHeaders();
		}).flat();
	}, getMemoOptions(table.options, debug, "getLeafHeaders"));
} };
function buildHeaderGroups(allColumns, columnsToGroup, table, headerFamily) {
	var _headerGroups$0$heade, _headerGroups$;
	let maxDepth = 0;
	const findMaxDepth = function(columns, depth) {
		if (depth === void 0) depth = 1;
		maxDepth = Math.max(maxDepth, depth);
		columns.filter((column) => column.getIsVisible()).forEach((column) => {
			var _column$columns;
			if ((_column$columns = column.columns) != null && _column$columns.length) findMaxDepth(column.columns, depth + 1);
		}, 0);
	};
	findMaxDepth(allColumns);
	let headerGroups = [];
	const createHeaderGroup = (headersToGroup, depth) => {
		const headerGroup = {
			depth,
			id: [headerFamily, `${depth}`].filter(Boolean).join("_"),
			headers: []
		};
		const pendingParentHeaders = [];
		headersToGroup.forEach((headerToGroup) => {
			const latestPendingParentHeader = [...pendingParentHeaders].reverse()[0];
			const isLeafHeader = headerToGroup.column.depth === headerGroup.depth;
			let column;
			let isPlaceholder = false;
			if (isLeafHeader && headerToGroup.column.parent) column = headerToGroup.column.parent;
			else {
				column = headerToGroup.column;
				isPlaceholder = true;
			}
			if (latestPendingParentHeader && (latestPendingParentHeader == null ? void 0 : latestPendingParentHeader.column) === column) latestPendingParentHeader.subHeaders.push(headerToGroup);
			else {
				const header = createHeader(table, column, {
					id: [
						headerFamily,
						depth,
						column.id,
						headerToGroup == null ? void 0 : headerToGroup.id
					].filter(Boolean).join("_"),
					isPlaceholder,
					placeholderId: isPlaceholder ? `${pendingParentHeaders.filter((d) => d.column === column).length}` : void 0,
					depth,
					index: pendingParentHeaders.length
				});
				header.subHeaders.push(headerToGroup);
				pendingParentHeaders.push(header);
			}
			headerGroup.headers.push(headerToGroup);
			headerToGroup.headerGroup = headerGroup;
		});
		headerGroups.push(headerGroup);
		if (depth > 0) createHeaderGroup(pendingParentHeaders, depth - 1);
	};
	createHeaderGroup(columnsToGroup.map((column, index) => createHeader(table, column, {
		depth: maxDepth,
		index
	})), maxDepth - 1);
	headerGroups.reverse();
	const recurseHeadersForSpans = (headers) => {
		return headers.filter((header) => header.column.getIsVisible()).map((header) => {
			let colSpan = 0;
			let rowSpan = 0;
			let childRowSpans = [0];
			if (header.subHeaders && header.subHeaders.length) {
				childRowSpans = [];
				recurseHeadersForSpans(header.subHeaders).forEach((_ref) => {
					let { colSpan: childColSpan, rowSpan: childRowSpan } = _ref;
					colSpan += childColSpan;
					childRowSpans.push(childRowSpan);
				});
			} else colSpan = 1;
			const minChildRowSpan = Math.min(...childRowSpans);
			rowSpan = rowSpan + minChildRowSpan;
			header.colSpan = colSpan;
			header.rowSpan = rowSpan;
			return {
				colSpan,
				rowSpan
			};
		});
	};
	recurseHeadersForSpans((_headerGroups$0$heade = (_headerGroups$ = headerGroups[0]) == null ? void 0 : _headerGroups$.headers) != null ? _headerGroups$0$heade : []);
	return headerGroups;
}
var createRow = (table, id, original, rowIndex, depth, subRows, parentId) => {
	let row = {
		id,
		index: rowIndex,
		original,
		depth,
		parentId,
		_valuesCache: {},
		_uniqueValuesCache: {},
		getValue: (columnId) => {
			if (row._valuesCache.hasOwnProperty(columnId)) return row._valuesCache[columnId];
			const column = table.getColumn(columnId);
			if (!(column != null && column.accessorFn)) return;
			row._valuesCache[columnId] = column.accessorFn(row.original, rowIndex);
			return row._valuesCache[columnId];
		},
		getUniqueValues: (columnId) => {
			if (row._uniqueValuesCache.hasOwnProperty(columnId)) return row._uniqueValuesCache[columnId];
			const column = table.getColumn(columnId);
			if (!(column != null && column.accessorFn)) return;
			if (!column.columnDef.getUniqueValues) {
				row._uniqueValuesCache[columnId] = [row.getValue(columnId)];
				return row._uniqueValuesCache[columnId];
			}
			row._uniqueValuesCache[columnId] = column.columnDef.getUniqueValues(row.original, rowIndex);
			return row._uniqueValuesCache[columnId];
		},
		renderValue: (columnId) => {
			var _row$getValue;
			return (_row$getValue = row.getValue(columnId)) != null ? _row$getValue : table.options.renderFallbackValue;
		},
		subRows: subRows != null ? subRows : [],
		getLeafRows: () => flattenBy(row.subRows, (d) => d.subRows),
		getParentRow: () => row.parentId ? table.getRow(row.parentId, true) : void 0,
		getParentRows: () => {
			let parentRows = [];
			let currentRow = row;
			while (true) {
				const parentRow = currentRow.getParentRow();
				if (!parentRow) break;
				parentRows.push(parentRow);
				currentRow = parentRow;
			}
			return parentRows.reverse();
		},
		getAllCells: memo$1(() => [table.getAllLeafColumns()], (leafColumns) => {
			return leafColumns.map((column) => {
				return createCell(table, row, column, column.id);
			});
		}, getMemoOptions(table.options, "debugRows", "getAllCells")),
		_getAllCellsByColumnId: memo$1(() => [row.getAllCells()], (allCells) => {
			return allCells.reduce((acc, cell) => {
				acc[cell.column.id] = cell;
				return acc;
			}, {});
		}, getMemoOptions(table.options, "debugRows", "getAllCellsByColumnId"))
	};
	for (let i = 0; i < table._features.length; i++) {
		const feature = table._features[i];
		feature == null || feature.createRow == null || feature.createRow(row, table);
	}
	return row;
};
var ColumnFaceting = { createColumn: (column, table) => {
	column._getFacetedRowModel = table.options.getFacetedRowModel && table.options.getFacetedRowModel(table, column.id);
	column.getFacetedRowModel = () => {
		if (!column._getFacetedRowModel) return table.getPreFilteredRowModel();
		return column._getFacetedRowModel();
	};
	column._getFacetedUniqueValues = table.options.getFacetedUniqueValues && table.options.getFacetedUniqueValues(table, column.id);
	column.getFacetedUniqueValues = () => {
		if (!column._getFacetedUniqueValues) return /* @__PURE__ */ new Map();
		return column._getFacetedUniqueValues();
	};
	column._getFacetedMinMaxValues = table.options.getFacetedMinMaxValues && table.options.getFacetedMinMaxValues(table, column.id);
	column.getFacetedMinMaxValues = () => {
		if (!column._getFacetedMinMaxValues) return;
		return column._getFacetedMinMaxValues();
	};
} };
var includesString = (row, columnId, filterValue) => {
	var _filterValue$toString, _row$getValue;
	const search = filterValue == null || (_filterValue$toString = filterValue.toString()) == null ? void 0 : _filterValue$toString.toLowerCase();
	return Boolean((_row$getValue = row.getValue(columnId)) == null || (_row$getValue = _row$getValue.toString()) == null || (_row$getValue = _row$getValue.toLowerCase()) == null ? void 0 : _row$getValue.includes(search));
};
includesString.autoRemove = (val) => testFalsey(val);
var includesStringSensitive = (row, columnId, filterValue) => {
	var _row$getValue2;
	return Boolean((_row$getValue2 = row.getValue(columnId)) == null || (_row$getValue2 = _row$getValue2.toString()) == null ? void 0 : _row$getValue2.includes(filterValue));
};
includesStringSensitive.autoRemove = (val) => testFalsey(val);
var equalsString = (row, columnId, filterValue) => {
	var _row$getValue3;
	return ((_row$getValue3 = row.getValue(columnId)) == null || (_row$getValue3 = _row$getValue3.toString()) == null ? void 0 : _row$getValue3.toLowerCase()) === (filterValue == null ? void 0 : filterValue.toLowerCase());
};
equalsString.autoRemove = (val) => testFalsey(val);
var arrIncludes = (row, columnId, filterValue) => {
	var _row$getValue4;
	return (_row$getValue4 = row.getValue(columnId)) == null ? void 0 : _row$getValue4.includes(filterValue);
};
arrIncludes.autoRemove = (val) => testFalsey(val);
var arrIncludesAll = (row, columnId, filterValue) => {
	return !filterValue.some((val) => {
		var _row$getValue5;
		return !((_row$getValue5 = row.getValue(columnId)) != null && _row$getValue5.includes(val));
	});
};
arrIncludesAll.autoRemove = (val) => testFalsey(val) || !(val != null && val.length);
var arrIncludesSome = (row, columnId, filterValue) => {
	return filterValue.some((val) => {
		var _row$getValue6;
		return (_row$getValue6 = row.getValue(columnId)) == null ? void 0 : _row$getValue6.includes(val);
	});
};
arrIncludesSome.autoRemove = (val) => testFalsey(val) || !(val != null && val.length);
var equals = (row, columnId, filterValue) => {
	return row.getValue(columnId) === filterValue;
};
equals.autoRemove = (val) => testFalsey(val);
var weakEquals = (row, columnId, filterValue) => {
	return row.getValue(columnId) == filterValue;
};
weakEquals.autoRemove = (val) => testFalsey(val);
var inNumberRange = (row, columnId, filterValue) => {
	let [min, max] = filterValue;
	const rowValue = row.getValue(columnId);
	return rowValue >= min && rowValue <= max;
};
inNumberRange.resolveFilterValue = (val) => {
	let [unsafeMin, unsafeMax] = val;
	let parsedMin = typeof unsafeMin !== "number" ? parseFloat(unsafeMin) : unsafeMin;
	let parsedMax = typeof unsafeMax !== "number" ? parseFloat(unsafeMax) : unsafeMax;
	let min = unsafeMin === null || Number.isNaN(parsedMin) ? -Infinity : parsedMin;
	let max = unsafeMax === null || Number.isNaN(parsedMax) ? Infinity : parsedMax;
	if (min > max) {
		const temp = min;
		min = max;
		max = temp;
	}
	return [min, max];
};
inNumberRange.autoRemove = (val) => testFalsey(val) || testFalsey(val[0]) && testFalsey(val[1]);
var filterFns = {
	includesString,
	includesStringSensitive,
	equalsString,
	arrIncludes,
	arrIncludesAll,
	arrIncludesSome,
	equals,
	weakEquals,
	inNumberRange
};
function testFalsey(val) {
	return val === void 0 || val === null || val === "";
}
var ColumnFiltering = {
	getDefaultColumnDef: () => {
		return { filterFn: "auto" };
	},
	getInitialState: (state) => {
		return {
			columnFilters: [],
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onColumnFiltersChange: makeStateUpdater("columnFilters", table),
			filterFromLeafRows: false,
			maxLeafRowFilterDepth: 100
		};
	},
	createColumn: (column, table) => {
		column.getAutoFilterFn = () => {
			const firstRow = table.getCoreRowModel().flatRows[0];
			const value = firstRow == null ? void 0 : firstRow.getValue(column.id);
			if (typeof value === "string") return filterFns.includesString;
			if (typeof value === "number") return filterFns.inNumberRange;
			if (typeof value === "boolean") return filterFns.equals;
			if (value !== null && typeof value === "object") return filterFns.equals;
			if (Array.isArray(value)) return filterFns.arrIncludes;
			return filterFns.weakEquals;
		};
		column.getFilterFn = () => {
			var _table$options$filter, _table$options$filter2;
			return isFunction(column.columnDef.filterFn) ? column.columnDef.filterFn : column.columnDef.filterFn === "auto" ? column.getAutoFilterFn() : (_table$options$filter = (_table$options$filter2 = table.options.filterFns) == null ? void 0 : _table$options$filter2[column.columnDef.filterFn]) != null ? _table$options$filter : filterFns[column.columnDef.filterFn];
		};
		column.getCanFilter = () => {
			var _column$columnDef$ena, _table$options$enable, _table$options$enable2;
			return ((_column$columnDef$ena = column.columnDef.enableColumnFilter) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableColumnFilters) != null ? _table$options$enable : true) && ((_table$options$enable2 = table.options.enableFilters) != null ? _table$options$enable2 : true) && !!column.accessorFn;
		};
		column.getIsFiltered = () => column.getFilterIndex() > -1;
		column.getFilterValue = () => {
			var _table$getState$colum;
			return (_table$getState$colum = table.getState().columnFilters) == null || (_table$getState$colum = _table$getState$colum.find((d) => d.id === column.id)) == null ? void 0 : _table$getState$colum.value;
		};
		column.getFilterIndex = () => {
			var _table$getState$colum2, _table$getState$colum3;
			return (_table$getState$colum2 = (_table$getState$colum3 = table.getState().columnFilters) == null ? void 0 : _table$getState$colum3.findIndex((d) => d.id === column.id)) != null ? _table$getState$colum2 : -1;
		};
		column.setFilterValue = (value) => {
			table.setColumnFilters((old) => {
				const filterFn = column.getFilterFn();
				const previousFilter = old == null ? void 0 : old.find((d) => d.id === column.id);
				const newFilter = functionalUpdate(value, previousFilter ? previousFilter.value : void 0);
				if (shouldAutoRemoveFilter(filterFn, newFilter, column)) {
					var _old$filter;
					return (_old$filter = old == null ? void 0 : old.filter((d) => d.id !== column.id)) != null ? _old$filter : [];
				}
				const newFilterObj = {
					id: column.id,
					value: newFilter
				};
				if (previousFilter) {
					var _old$map;
					return (_old$map = old == null ? void 0 : old.map((d) => {
						if (d.id === column.id) return newFilterObj;
						return d;
					})) != null ? _old$map : [];
				}
				if (old != null && old.length) return [...old, newFilterObj];
				return [newFilterObj];
			});
		};
	},
	createRow: (row, _table) => {
		row.columnFilters = {};
		row.columnFiltersMeta = {};
	},
	createTable: (table) => {
		table.setColumnFilters = (updater) => {
			const leafColumns = table.getAllLeafColumns();
			const updateFn = (old) => {
				var _functionalUpdate;
				return (_functionalUpdate = functionalUpdate(updater, old)) == null ? void 0 : _functionalUpdate.filter((filter) => {
					const column = leafColumns.find((d) => d.id === filter.id);
					if (column) {
						if (shouldAutoRemoveFilter(column.getFilterFn(), filter.value, column)) return false;
					}
					return true;
				});
			};
			table.options.onColumnFiltersChange == null || table.options.onColumnFiltersChange(updateFn);
		};
		table.resetColumnFilters = (defaultState) => {
			var _table$initialState$c, _table$initialState;
			table.setColumnFilters(defaultState ? [] : (_table$initialState$c = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.columnFilters) != null ? _table$initialState$c : []);
		};
		table.getPreFilteredRowModel = () => table.getCoreRowModel();
		table.getFilteredRowModel = () => {
			if (!table._getFilteredRowModel && table.options.getFilteredRowModel) table._getFilteredRowModel = table.options.getFilteredRowModel(table);
			if (table.options.manualFiltering || !table._getFilteredRowModel) return table.getPreFilteredRowModel();
			return table._getFilteredRowModel();
		};
	}
};
function shouldAutoRemoveFilter(filterFn, value, column) {
	return (filterFn && filterFn.autoRemove ? filterFn.autoRemove(value, column) : false) || typeof value === "undefined" || typeof value === "string" && !value;
}
var sum = (columnId, _leafRows, childRows) => {
	return childRows.reduce((sum, next) => {
		const nextValue = next.getValue(columnId);
		return sum + (typeof nextValue === "number" ? nextValue : 0);
	}, 0);
};
var min = (columnId, _leafRows, childRows) => {
	let min;
	childRows.forEach((row) => {
		const value = row.getValue(columnId);
		if (value != null && (min > value || min === void 0 && value >= value)) min = value;
	});
	return min;
};
var max = (columnId, _leafRows, childRows) => {
	let max;
	childRows.forEach((row) => {
		const value = row.getValue(columnId);
		if (value != null && (max < value || max === void 0 && value >= value)) max = value;
	});
	return max;
};
var extent = (columnId, _leafRows, childRows) => {
	let min;
	let max;
	childRows.forEach((row) => {
		const value = row.getValue(columnId);
		if (value != null) if (min === void 0) {
			if (value >= value) min = max = value;
		} else {
			if (min > value) min = value;
			if (max < value) max = value;
		}
	});
	return [min, max];
};
var mean = (columnId, leafRows) => {
	let count = 0;
	let sum = 0;
	leafRows.forEach((row) => {
		let value = row.getValue(columnId);
		if (value != null && (value = +value) >= value) ++count, sum += value;
	});
	if (count) return sum / count;
};
var median = (columnId, leafRows) => {
	if (!leafRows.length) return;
	const values = leafRows.map((row) => row.getValue(columnId));
	if (!isNumberArray(values)) return;
	if (values.length === 1) return values[0];
	const mid = Math.floor(values.length / 2);
	const nums = values.sort((a, b) => a - b);
	return values.length % 2 !== 0 ? nums[mid] : (nums[mid - 1] + nums[mid]) / 2;
};
var unique = (columnId, leafRows) => {
	return Array.from(new Set(leafRows.map((d) => d.getValue(columnId))).values());
};
var uniqueCount = (columnId, leafRows) => {
	return new Set(leafRows.map((d) => d.getValue(columnId))).size;
};
var count = (_columnId, leafRows) => {
	return leafRows.length;
};
var aggregationFns = {
	sum,
	min,
	max,
	extent,
	mean,
	median,
	unique,
	uniqueCount,
	count
};
var ColumnGrouping = {
	getDefaultColumnDef: () => {
		return {
			aggregatedCell: (props) => {
				var _toString, _props$getValue;
				return (_toString = (_props$getValue = props.getValue()) == null || _props$getValue.toString == null ? void 0 : _props$getValue.toString()) != null ? _toString : null;
			},
			aggregationFn: "auto"
		};
	},
	getInitialState: (state) => {
		return {
			grouping: [],
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onGroupingChange: makeStateUpdater("grouping", table),
			groupedColumnMode: "reorder"
		};
	},
	createColumn: (column, table) => {
		column.toggleGrouping = () => {
			table.setGrouping((old) => {
				if (old != null && old.includes(column.id)) return old.filter((d) => d !== column.id);
				return [...old != null ? old : [], column.id];
			});
		};
		column.getCanGroup = () => {
			var _column$columnDef$ena, _table$options$enable;
			return ((_column$columnDef$ena = column.columnDef.enableGrouping) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableGrouping) != null ? _table$options$enable : true) && (!!column.accessorFn || !!column.columnDef.getGroupingValue);
		};
		column.getIsGrouped = () => {
			var _table$getState$group;
			return (_table$getState$group = table.getState().grouping) == null ? void 0 : _table$getState$group.includes(column.id);
		};
		column.getGroupedIndex = () => {
			var _table$getState$group2;
			return (_table$getState$group2 = table.getState().grouping) == null ? void 0 : _table$getState$group2.indexOf(column.id);
		};
		column.getToggleGroupingHandler = () => {
			const canGroup = column.getCanGroup();
			return () => {
				if (!canGroup) return;
				column.toggleGrouping();
			};
		};
		column.getAutoAggregationFn = () => {
			const firstRow = table.getCoreRowModel().flatRows[0];
			const value = firstRow == null ? void 0 : firstRow.getValue(column.id);
			if (typeof value === "number") return aggregationFns.sum;
			if (Object.prototype.toString.call(value) === "[object Date]") return aggregationFns.extent;
		};
		column.getAggregationFn = () => {
			var _table$options$aggreg, _table$options$aggreg2;
			if (!column) throw new Error();
			return isFunction(column.columnDef.aggregationFn) ? column.columnDef.aggregationFn : column.columnDef.aggregationFn === "auto" ? column.getAutoAggregationFn() : (_table$options$aggreg = (_table$options$aggreg2 = table.options.aggregationFns) == null ? void 0 : _table$options$aggreg2[column.columnDef.aggregationFn]) != null ? _table$options$aggreg : aggregationFns[column.columnDef.aggregationFn];
		};
	},
	createTable: (table) => {
		table.setGrouping = (updater) => table.options.onGroupingChange == null ? void 0 : table.options.onGroupingChange(updater);
		table.resetGrouping = (defaultState) => {
			var _table$initialState$g, _table$initialState;
			table.setGrouping(defaultState ? [] : (_table$initialState$g = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.grouping) != null ? _table$initialState$g : []);
		};
		table.getPreGroupedRowModel = () => table.getFilteredRowModel();
		table.getGroupedRowModel = () => {
			if (!table._getGroupedRowModel && table.options.getGroupedRowModel) table._getGroupedRowModel = table.options.getGroupedRowModel(table);
			if (table.options.manualGrouping || !table._getGroupedRowModel) return table.getPreGroupedRowModel();
			return table._getGroupedRowModel();
		};
	},
	createRow: (row, table) => {
		row.getIsGrouped = () => !!row.groupingColumnId;
		row.getGroupingValue = (columnId) => {
			if (row._groupingValuesCache.hasOwnProperty(columnId)) return row._groupingValuesCache[columnId];
			const column = table.getColumn(columnId);
			if (!(column != null && column.columnDef.getGroupingValue)) return row.getValue(columnId);
			row._groupingValuesCache[columnId] = column.columnDef.getGroupingValue(row.original);
			return row._groupingValuesCache[columnId];
		};
		row._groupingValuesCache = {};
	},
	createCell: (cell, column, row, table) => {
		cell.getIsGrouped = () => column.getIsGrouped() && column.id === row.groupingColumnId;
		cell.getIsPlaceholder = () => !cell.getIsGrouped() && column.getIsGrouped();
		cell.getIsAggregated = () => {
			var _row$subRows;
			return !cell.getIsGrouped() && !cell.getIsPlaceholder() && !!((_row$subRows = row.subRows) != null && _row$subRows.length);
		};
	}
};
function orderColumns(leafColumns, grouping, groupedColumnMode) {
	if (!(grouping != null && grouping.length) || !groupedColumnMode) return leafColumns;
	const nonGroupingColumns = leafColumns.filter((col) => !grouping.includes(col.id));
	if (groupedColumnMode === "remove") return nonGroupingColumns;
	return [...grouping.map((g) => leafColumns.find((col) => col.id === g)).filter(Boolean), ...nonGroupingColumns];
}
var ColumnOrdering = {
	getInitialState: (state) => {
		return {
			columnOrder: [],
			...state
		};
	},
	getDefaultOptions: (table) => {
		return { onColumnOrderChange: makeStateUpdater("columnOrder", table) };
	},
	createColumn: (column, table) => {
		column.getIndex = memo$1((position) => [_getVisibleLeafColumns(table, position)], (columns) => columns.findIndex((d) => d.id === column.id), getMemoOptions(table.options, "debugColumns", "getIndex"));
		column.getIsFirstColumn = (position) => {
			var _columns$;
			return ((_columns$ = _getVisibleLeafColumns(table, position)[0]) == null ? void 0 : _columns$.id) === column.id;
		};
		column.getIsLastColumn = (position) => {
			var _columns;
			const columns = _getVisibleLeafColumns(table, position);
			return ((_columns = columns[columns.length - 1]) == null ? void 0 : _columns.id) === column.id;
		};
	},
	createTable: (table) => {
		table.setColumnOrder = (updater) => table.options.onColumnOrderChange == null ? void 0 : table.options.onColumnOrderChange(updater);
		table.resetColumnOrder = (defaultState) => {
			var _table$initialState$c;
			table.setColumnOrder(defaultState ? [] : (_table$initialState$c = table.initialState.columnOrder) != null ? _table$initialState$c : []);
		};
		table._getOrderColumnsFn = memo$1(() => [
			table.getState().columnOrder,
			table.getState().grouping,
			table.options.groupedColumnMode
		], (columnOrder, grouping, groupedColumnMode) => (columns) => {
			let orderedColumns = [];
			if (!(columnOrder != null && columnOrder.length)) orderedColumns = columns;
			else {
				const columnOrderCopy = [...columnOrder];
				const columnsCopy = [...columns];
				while (columnsCopy.length && columnOrderCopy.length) {
					const targetColumnId = columnOrderCopy.shift();
					const foundIndex = columnsCopy.findIndex((d) => d.id === targetColumnId);
					if (foundIndex > -1) orderedColumns.push(columnsCopy.splice(foundIndex, 1)[0]);
				}
				orderedColumns = [...orderedColumns, ...columnsCopy];
			}
			return orderColumns(orderedColumns, grouping, groupedColumnMode);
		}, getMemoOptions(table.options, "debugTable", "_getOrderColumnsFn"));
	}
};
var getDefaultColumnPinningState = () => ({
	left: [],
	right: []
});
var ColumnPinning = {
	getInitialState: (state) => {
		return {
			columnPinning: getDefaultColumnPinningState(),
			...state
		};
	},
	getDefaultOptions: (table) => {
		return { onColumnPinningChange: makeStateUpdater("columnPinning", table) };
	},
	createColumn: (column, table) => {
		column.pin = (position) => {
			const columnIds = column.getLeafColumns().map((d) => d.id).filter(Boolean);
			table.setColumnPinning((old) => {
				var _old$left3, _old$right3;
				if (position === "right") {
					var _old$left, _old$right;
					return {
						left: ((_old$left = old == null ? void 0 : old.left) != null ? _old$left : []).filter((d) => !(columnIds != null && columnIds.includes(d))),
						right: [...((_old$right = old == null ? void 0 : old.right) != null ? _old$right : []).filter((d) => !(columnIds != null && columnIds.includes(d))), ...columnIds]
					};
				}
				if (position === "left") {
					var _old$left2, _old$right2;
					return {
						left: [...((_old$left2 = old == null ? void 0 : old.left) != null ? _old$left2 : []).filter((d) => !(columnIds != null && columnIds.includes(d))), ...columnIds],
						right: ((_old$right2 = old == null ? void 0 : old.right) != null ? _old$right2 : []).filter((d) => !(columnIds != null && columnIds.includes(d)))
					};
				}
				return {
					left: ((_old$left3 = old == null ? void 0 : old.left) != null ? _old$left3 : []).filter((d) => !(columnIds != null && columnIds.includes(d))),
					right: ((_old$right3 = old == null ? void 0 : old.right) != null ? _old$right3 : []).filter((d) => !(columnIds != null && columnIds.includes(d)))
				};
			});
		};
		column.getCanPin = () => {
			return column.getLeafColumns().some((d) => {
				var _d$columnDef$enablePi, _ref, _table$options$enable;
				return ((_d$columnDef$enablePi = d.columnDef.enablePinning) != null ? _d$columnDef$enablePi : true) && ((_ref = (_table$options$enable = table.options.enableColumnPinning) != null ? _table$options$enable : table.options.enablePinning) != null ? _ref : true);
			});
		};
		column.getIsPinned = () => {
			const leafColumnIds = column.getLeafColumns().map((d) => d.id);
			const { left, right } = table.getState().columnPinning;
			const isLeft = leafColumnIds.some((d) => left == null ? void 0 : left.includes(d));
			const isRight = leafColumnIds.some((d) => right == null ? void 0 : right.includes(d));
			return isLeft ? "left" : isRight ? "right" : false;
		};
		column.getPinnedIndex = () => {
			var _table$getState$colum, _table$getState$colum2;
			const position = column.getIsPinned();
			return position ? (_table$getState$colum = (_table$getState$colum2 = table.getState().columnPinning) == null || (_table$getState$colum2 = _table$getState$colum2[position]) == null ? void 0 : _table$getState$colum2.indexOf(column.id)) != null ? _table$getState$colum : -1 : 0;
		};
	},
	createRow: (row, table) => {
		row.getCenterVisibleCells = memo$1(() => [
			row._getAllVisibleCells(),
			table.getState().columnPinning.left,
			table.getState().columnPinning.right
		], (allCells, left, right) => {
			const leftAndRight = [...left != null ? left : [], ...right != null ? right : []];
			return allCells.filter((d) => !leftAndRight.includes(d.column.id));
		}, getMemoOptions(table.options, "debugRows", "getCenterVisibleCells"));
		row.getLeftVisibleCells = memo$1(() => [row._getAllVisibleCells(), table.getState().columnPinning.left], (allCells, left) => {
			return (left != null ? left : []).map((columnId) => allCells.find((cell) => cell.column.id === columnId)).filter(Boolean).map((d) => ({
				...d,
				position: "left"
			}));
		}, getMemoOptions(table.options, "debugRows", "getLeftVisibleCells"));
		row.getRightVisibleCells = memo$1(() => [row._getAllVisibleCells(), table.getState().columnPinning.right], (allCells, right) => {
			return (right != null ? right : []).map((columnId) => allCells.find((cell) => cell.column.id === columnId)).filter(Boolean).map((d) => ({
				...d,
				position: "right"
			}));
		}, getMemoOptions(table.options, "debugRows", "getRightVisibleCells"));
	},
	createTable: (table) => {
		table.setColumnPinning = (updater) => table.options.onColumnPinningChange == null ? void 0 : table.options.onColumnPinningChange(updater);
		table.resetColumnPinning = (defaultState) => {
			var _table$initialState$c, _table$initialState;
			return table.setColumnPinning(defaultState ? getDefaultColumnPinningState() : (_table$initialState$c = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.columnPinning) != null ? _table$initialState$c : getDefaultColumnPinningState());
		};
		table.getIsSomeColumnsPinned = (position) => {
			var _pinningState$positio;
			const pinningState = table.getState().columnPinning;
			if (!position) {
				var _pinningState$left, _pinningState$right;
				return Boolean(((_pinningState$left = pinningState.left) == null ? void 0 : _pinningState$left.length) || ((_pinningState$right = pinningState.right) == null ? void 0 : _pinningState$right.length));
			}
			return Boolean((_pinningState$positio = pinningState[position]) == null ? void 0 : _pinningState$positio.length);
		};
		table.getLeftLeafColumns = memo$1(() => [table.getAllLeafColumns(), table.getState().columnPinning.left], (allColumns, left) => {
			return (left != null ? left : []).map((columnId) => allColumns.find((column) => column.id === columnId)).filter(Boolean);
		}, getMemoOptions(table.options, "debugColumns", "getLeftLeafColumns"));
		table.getRightLeafColumns = memo$1(() => [table.getAllLeafColumns(), table.getState().columnPinning.right], (allColumns, right) => {
			return (right != null ? right : []).map((columnId) => allColumns.find((column) => column.id === columnId)).filter(Boolean);
		}, getMemoOptions(table.options, "debugColumns", "getRightLeafColumns"));
		table.getCenterLeafColumns = memo$1(() => [
			table.getAllLeafColumns(),
			table.getState().columnPinning.left,
			table.getState().columnPinning.right
		], (allColumns, left, right) => {
			const leftAndRight = [...left != null ? left : [], ...right != null ? right : []];
			return allColumns.filter((d) => !leftAndRight.includes(d.id));
		}, getMemoOptions(table.options, "debugColumns", "getCenterLeafColumns"));
	}
};
function safelyAccessDocument(_document) {
	return _document || (typeof document !== "undefined" ? document : null);
}
var defaultColumnSizing = {
	size: 150,
	minSize: 20,
	maxSize: Number.MAX_SAFE_INTEGER
};
var getDefaultColumnSizingInfoState = () => ({
	startOffset: null,
	startSize: null,
	deltaOffset: null,
	deltaPercentage: null,
	isResizingColumn: false,
	columnSizingStart: []
});
var ColumnSizing = {
	getDefaultColumnDef: () => {
		return defaultColumnSizing;
	},
	getInitialState: (state) => {
		return {
			columnSizing: {},
			columnSizingInfo: getDefaultColumnSizingInfoState(),
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			columnResizeMode: "onEnd",
			columnResizeDirection: "ltr",
			onColumnSizingChange: makeStateUpdater("columnSizing", table),
			onColumnSizingInfoChange: makeStateUpdater("columnSizingInfo", table)
		};
	},
	createColumn: (column, table) => {
		column.getSize = () => {
			var _column$columnDef$min, _ref, _column$columnDef$max;
			const columnSize = table.getState().columnSizing[column.id];
			return Math.min(Math.max((_column$columnDef$min = column.columnDef.minSize) != null ? _column$columnDef$min : defaultColumnSizing.minSize, (_ref = columnSize != null ? columnSize : column.columnDef.size) != null ? _ref : defaultColumnSizing.size), (_column$columnDef$max = column.columnDef.maxSize) != null ? _column$columnDef$max : defaultColumnSizing.maxSize);
		};
		column.getStart = memo$1((position) => [
			position,
			_getVisibleLeafColumns(table, position),
			table.getState().columnSizing
		], (position, columns) => columns.slice(0, column.getIndex(position)).reduce((sum, column) => sum + column.getSize(), 0), getMemoOptions(table.options, "debugColumns", "getStart"));
		column.getAfter = memo$1((position) => [
			position,
			_getVisibleLeafColumns(table, position),
			table.getState().columnSizing
		], (position, columns) => columns.slice(column.getIndex(position) + 1).reduce((sum, column) => sum + column.getSize(), 0), getMemoOptions(table.options, "debugColumns", "getAfter"));
		column.resetSize = () => {
			table.setColumnSizing((_ref2) => {
				let { [column.id]: _, ...rest } = _ref2;
				return rest;
			});
		};
		column.getCanResize = () => {
			var _column$columnDef$ena, _table$options$enable;
			return ((_column$columnDef$ena = column.columnDef.enableResizing) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableColumnResizing) != null ? _table$options$enable : true);
		};
		column.getIsResizing = () => {
			return table.getState().columnSizingInfo.isResizingColumn === column.id;
		};
	},
	createHeader: (header, table) => {
		header.getSize = () => {
			let sum = 0;
			const recurse = (header) => {
				if (header.subHeaders.length) header.subHeaders.forEach(recurse);
				else {
					var _header$column$getSiz;
					sum += (_header$column$getSiz = header.column.getSize()) != null ? _header$column$getSiz : 0;
				}
			};
			recurse(header);
			return sum;
		};
		header.getStart = () => {
			if (header.index > 0) {
				const prevSiblingHeader = header.headerGroup.headers[header.index - 1];
				return prevSiblingHeader.getStart() + prevSiblingHeader.getSize();
			}
			return 0;
		};
		header.getResizeHandler = (_contextDocument) => {
			const column = table.getColumn(header.column.id);
			const canResize = column == null ? void 0 : column.getCanResize();
			return (e) => {
				if (!column || !canResize) return;
				e.persist == null || e.persist();
				if (isTouchStartEvent(e)) {
					if (e.touches && e.touches.length > 1) return;
				}
				const startSize = header.getSize();
				const columnSizingStart = header ? header.getLeafHeaders().map((d) => [d.column.id, d.column.getSize()]) : [[column.id, column.getSize()]];
				const clientX = isTouchStartEvent(e) ? Math.round(e.touches[0].clientX) : e.clientX;
				const newColumnSizing = {};
				const updateOffset = (eventType, clientXPos) => {
					if (typeof clientXPos !== "number") return;
					table.setColumnSizingInfo((old) => {
						var _old$startOffset, _old$startSize;
						const deltaDirection = table.options.columnResizeDirection === "rtl" ? -1 : 1;
						const deltaOffset = (clientXPos - ((_old$startOffset = old == null ? void 0 : old.startOffset) != null ? _old$startOffset : 0)) * deltaDirection;
						const deltaPercentage = Math.max(deltaOffset / ((_old$startSize = old == null ? void 0 : old.startSize) != null ? _old$startSize : 0), -.999999);
						old.columnSizingStart.forEach((_ref3) => {
							let [columnId, headerSize] = _ref3;
							newColumnSizing[columnId] = Math.round(Math.max(headerSize + headerSize * deltaPercentage, 0) * 100) / 100;
						});
						return {
							...old,
							deltaOffset,
							deltaPercentage
						};
					});
					if (table.options.columnResizeMode === "onChange" || eventType === "end") table.setColumnSizing((old) => ({
						...old,
						...newColumnSizing
					}));
				};
				const onMove = (clientXPos) => updateOffset("move", clientXPos);
				const onEnd = (clientXPos) => {
					updateOffset("end", clientXPos);
					table.setColumnSizingInfo((old) => ({
						...old,
						isResizingColumn: false,
						startOffset: null,
						startSize: null,
						deltaOffset: null,
						deltaPercentage: null,
						columnSizingStart: []
					}));
				};
				const contextDocument = safelyAccessDocument(_contextDocument);
				const mouseEvents = {
					moveHandler: (e) => onMove(e.clientX),
					upHandler: (e) => {
						contextDocument?.removeEventListener("mousemove", mouseEvents.moveHandler);
						contextDocument?.removeEventListener("mouseup", mouseEvents.upHandler);
						onEnd(e.clientX);
					}
				};
				const touchEvents = {
					moveHandler: (e) => {
						if (e.cancelable) {
							e.preventDefault();
							e.stopPropagation();
						}
						onMove(e.touches[0].clientX);
						return false;
					},
					upHandler: (e) => {
						var _e$touches$;
						contextDocument?.removeEventListener("touchmove", touchEvents.moveHandler);
						contextDocument?.removeEventListener("touchend", touchEvents.upHandler);
						if (e.cancelable) {
							e.preventDefault();
							e.stopPropagation();
						}
						onEnd((_e$touches$ = e.touches[0]) == null ? void 0 : _e$touches$.clientX);
					}
				};
				const passiveIfSupported = passiveEventSupported() ? { passive: false } : false;
				if (isTouchStartEvent(e)) {
					contextDocument?.addEventListener("touchmove", touchEvents.moveHandler, passiveIfSupported);
					contextDocument?.addEventListener("touchend", touchEvents.upHandler, passiveIfSupported);
				} else {
					contextDocument?.addEventListener("mousemove", mouseEvents.moveHandler, passiveIfSupported);
					contextDocument?.addEventListener("mouseup", mouseEvents.upHandler, passiveIfSupported);
				}
				table.setColumnSizingInfo((old) => ({
					...old,
					startOffset: clientX,
					startSize,
					deltaOffset: 0,
					deltaPercentage: 0,
					columnSizingStart,
					isResizingColumn: column.id
				}));
			};
		};
	},
	createTable: (table) => {
		table.setColumnSizing = (updater) => table.options.onColumnSizingChange == null ? void 0 : table.options.onColumnSizingChange(updater);
		table.setColumnSizingInfo = (updater) => table.options.onColumnSizingInfoChange == null ? void 0 : table.options.onColumnSizingInfoChange(updater);
		table.resetColumnSizing = (defaultState) => {
			var _table$initialState$c;
			table.setColumnSizing(defaultState ? {} : (_table$initialState$c = table.initialState.columnSizing) != null ? _table$initialState$c : {});
		};
		table.resetHeaderSizeInfo = (defaultState) => {
			var _table$initialState$c2;
			table.setColumnSizingInfo(defaultState ? getDefaultColumnSizingInfoState() : (_table$initialState$c2 = table.initialState.columnSizingInfo) != null ? _table$initialState$c2 : getDefaultColumnSizingInfoState());
		};
		table.getTotalSize = () => {
			var _table$getHeaderGroup, _table$getHeaderGroup2;
			return (_table$getHeaderGroup = (_table$getHeaderGroup2 = table.getHeaderGroups()[0]) == null ? void 0 : _table$getHeaderGroup2.headers.reduce((sum, header) => {
				return sum + header.getSize();
			}, 0)) != null ? _table$getHeaderGroup : 0;
		};
		table.getLeftTotalSize = () => {
			var _table$getLeftHeaderG, _table$getLeftHeaderG2;
			return (_table$getLeftHeaderG = (_table$getLeftHeaderG2 = table.getLeftHeaderGroups()[0]) == null ? void 0 : _table$getLeftHeaderG2.headers.reduce((sum, header) => {
				return sum + header.getSize();
			}, 0)) != null ? _table$getLeftHeaderG : 0;
		};
		table.getCenterTotalSize = () => {
			var _table$getCenterHeade, _table$getCenterHeade2;
			return (_table$getCenterHeade = (_table$getCenterHeade2 = table.getCenterHeaderGroups()[0]) == null ? void 0 : _table$getCenterHeade2.headers.reduce((sum, header) => {
				return sum + header.getSize();
			}, 0)) != null ? _table$getCenterHeade : 0;
		};
		table.getRightTotalSize = () => {
			var _table$getRightHeader, _table$getRightHeader2;
			return (_table$getRightHeader = (_table$getRightHeader2 = table.getRightHeaderGroups()[0]) == null ? void 0 : _table$getRightHeader2.headers.reduce((sum, header) => {
				return sum + header.getSize();
			}, 0)) != null ? _table$getRightHeader : 0;
		};
	}
};
var passiveSupported = null;
function passiveEventSupported() {
	if (typeof passiveSupported === "boolean") return passiveSupported;
	let supported = false;
	try {
		const options = { get passive() {
			supported = true;
			return false;
		} };
		const noop = () => {};
		window.addEventListener("test", noop, options);
		window.removeEventListener("test", noop);
	} catch (err) {
		supported = false;
	}
	passiveSupported = supported;
	return passiveSupported;
}
function isTouchStartEvent(e) {
	return e.type === "touchstart";
}
var ColumnVisibility = {
	getInitialState: (state) => {
		return {
			columnVisibility: {},
			...state
		};
	},
	getDefaultOptions: (table) => {
		return { onColumnVisibilityChange: makeStateUpdater("columnVisibility", table) };
	},
	createColumn: (column, table) => {
		column.toggleVisibility = (value) => {
			if (column.getCanHide()) table.setColumnVisibility((old) => ({
				...old,
				[column.id]: value != null ? value : !column.getIsVisible()
			}));
		};
		column.getIsVisible = () => {
			var _ref, _table$getState$colum;
			const childColumns = column.columns;
			return (_ref = childColumns.length ? childColumns.some((c) => c.getIsVisible()) : (_table$getState$colum = table.getState().columnVisibility) == null ? void 0 : _table$getState$colum[column.id]) != null ? _ref : true;
		};
		column.getCanHide = () => {
			var _column$columnDef$ena, _table$options$enable;
			return ((_column$columnDef$ena = column.columnDef.enableHiding) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableHiding) != null ? _table$options$enable : true);
		};
		column.getToggleVisibilityHandler = () => {
			return (e) => {
				column.toggleVisibility == null || column.toggleVisibility(e.target.checked);
			};
		};
	},
	createRow: (row, table) => {
		row._getAllVisibleCells = memo$1(() => [row.getAllCells(), table.getState().columnVisibility], (cells) => {
			return cells.filter((cell) => cell.column.getIsVisible());
		}, getMemoOptions(table.options, "debugRows", "_getAllVisibleCells"));
		row.getVisibleCells = memo$1(() => [
			row.getLeftVisibleCells(),
			row.getCenterVisibleCells(),
			row.getRightVisibleCells()
		], (left, center, right) => [
			...left,
			...center,
			...right
		], getMemoOptions(table.options, "debugRows", "getVisibleCells"));
	},
	createTable: (table) => {
		const makeVisibleColumnsMethod = (key, getColumns) => {
			return memo$1(() => [getColumns(), getColumns().filter((d) => d.getIsVisible()).map((d) => d.id).join("_")], (columns) => {
				return columns.filter((d) => d.getIsVisible == null ? void 0 : d.getIsVisible());
			}, getMemoOptions(table.options, "debugColumns", key));
		};
		table.getVisibleFlatColumns = makeVisibleColumnsMethod("getVisibleFlatColumns", () => table.getAllFlatColumns());
		table.getVisibleLeafColumns = makeVisibleColumnsMethod("getVisibleLeafColumns", () => table.getAllLeafColumns());
		table.getLeftVisibleLeafColumns = makeVisibleColumnsMethod("getLeftVisibleLeafColumns", () => table.getLeftLeafColumns());
		table.getRightVisibleLeafColumns = makeVisibleColumnsMethod("getRightVisibleLeafColumns", () => table.getRightLeafColumns());
		table.getCenterVisibleLeafColumns = makeVisibleColumnsMethod("getCenterVisibleLeafColumns", () => table.getCenterLeafColumns());
		table.setColumnVisibility = (updater) => table.options.onColumnVisibilityChange == null ? void 0 : table.options.onColumnVisibilityChange(updater);
		table.resetColumnVisibility = (defaultState) => {
			var _table$initialState$c;
			table.setColumnVisibility(defaultState ? {} : (_table$initialState$c = table.initialState.columnVisibility) != null ? _table$initialState$c : {});
		};
		table.toggleAllColumnsVisible = (value) => {
			var _value;
			value = (_value = value) != null ? _value : !table.getIsAllColumnsVisible();
			table.setColumnVisibility(table.getAllLeafColumns().reduce((obj, column) => ({
				...obj,
				[column.id]: !value ? !(column.getCanHide != null && column.getCanHide()) : value
			}), {}));
		};
		table.getIsAllColumnsVisible = () => !table.getAllLeafColumns().some((column) => !(column.getIsVisible != null && column.getIsVisible()));
		table.getIsSomeColumnsVisible = () => table.getAllLeafColumns().some((column) => column.getIsVisible == null ? void 0 : column.getIsVisible());
		table.getToggleAllColumnsVisibilityHandler = () => {
			return (e) => {
				var _target;
				table.toggleAllColumnsVisible((_target = e.target) == null ? void 0 : _target.checked);
			};
		};
	}
};
function _getVisibleLeafColumns(table, position) {
	return !position ? table.getVisibleLeafColumns() : position === "center" ? table.getCenterVisibleLeafColumns() : position === "left" ? table.getLeftVisibleLeafColumns() : table.getRightVisibleLeafColumns();
}
var GlobalFaceting = { createTable: (table) => {
	table._getGlobalFacetedRowModel = table.options.getFacetedRowModel && table.options.getFacetedRowModel(table, "__global__");
	table.getGlobalFacetedRowModel = () => {
		if (table.options.manualFiltering || !table._getGlobalFacetedRowModel) return table.getPreFilteredRowModel();
		return table._getGlobalFacetedRowModel();
	};
	table._getGlobalFacetedUniqueValues = table.options.getFacetedUniqueValues && table.options.getFacetedUniqueValues(table, "__global__");
	table.getGlobalFacetedUniqueValues = () => {
		if (!table._getGlobalFacetedUniqueValues) return /* @__PURE__ */ new Map();
		return table._getGlobalFacetedUniqueValues();
	};
	table._getGlobalFacetedMinMaxValues = table.options.getFacetedMinMaxValues && table.options.getFacetedMinMaxValues(table, "__global__");
	table.getGlobalFacetedMinMaxValues = () => {
		if (!table._getGlobalFacetedMinMaxValues) return;
		return table._getGlobalFacetedMinMaxValues();
	};
} };
var GlobalFiltering = {
	getInitialState: (state) => {
		return {
			globalFilter: void 0,
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onGlobalFilterChange: makeStateUpdater("globalFilter", table),
			globalFilterFn: "auto",
			getColumnCanGlobalFilter: (column) => {
				var _table$getCoreRowMode;
				const value = (_table$getCoreRowMode = table.getCoreRowModel().flatRows[0]) == null || (_table$getCoreRowMode = _table$getCoreRowMode._getAllCellsByColumnId()[column.id]) == null ? void 0 : _table$getCoreRowMode.getValue();
				return typeof value === "string" || typeof value === "number";
			}
		};
	},
	createColumn: (column, table) => {
		column.getCanGlobalFilter = () => {
			var _column$columnDef$ena, _table$options$enable, _table$options$enable2, _table$options$getCol;
			return ((_column$columnDef$ena = column.columnDef.enableGlobalFilter) != null ? _column$columnDef$ena : true) && ((_table$options$enable = table.options.enableGlobalFilter) != null ? _table$options$enable : true) && ((_table$options$enable2 = table.options.enableFilters) != null ? _table$options$enable2 : true) && ((_table$options$getCol = table.options.getColumnCanGlobalFilter == null ? void 0 : table.options.getColumnCanGlobalFilter(column)) != null ? _table$options$getCol : true) && !!column.accessorFn;
		};
	},
	createTable: (table) => {
		table.getGlobalAutoFilterFn = () => {
			return filterFns.includesString;
		};
		table.getGlobalFilterFn = () => {
			var _table$options$filter, _table$options$filter2;
			const { globalFilterFn } = table.options;
			return isFunction(globalFilterFn) ? globalFilterFn : globalFilterFn === "auto" ? table.getGlobalAutoFilterFn() : (_table$options$filter = (_table$options$filter2 = table.options.filterFns) == null ? void 0 : _table$options$filter2[globalFilterFn]) != null ? _table$options$filter : filterFns[globalFilterFn];
		};
		table.setGlobalFilter = (updater) => {
			table.options.onGlobalFilterChange == null || table.options.onGlobalFilterChange(updater);
		};
		table.resetGlobalFilter = (defaultState) => {
			table.setGlobalFilter(defaultState ? void 0 : table.initialState.globalFilter);
		};
	}
};
var RowExpanding = {
	getInitialState: (state) => {
		return {
			expanded: {},
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onExpandedChange: makeStateUpdater("expanded", table),
			paginateExpandedRows: true
		};
	},
	createTable: (table) => {
		let registered = false;
		let queued = false;
		table._autoResetExpanded = () => {
			var _ref, _table$options$autoRe;
			if (!registered) {
				table._queue(() => {
					registered = true;
				});
				return;
			}
			if ((_ref = (_table$options$autoRe = table.options.autoResetAll) != null ? _table$options$autoRe : table.options.autoResetExpanded) != null ? _ref : !table.options.manualExpanding) {
				if (queued) return;
				queued = true;
				table._queue(() => {
					table.resetExpanded();
					queued = false;
				});
			}
		};
		table.setExpanded = (updater) => table.options.onExpandedChange == null ? void 0 : table.options.onExpandedChange(updater);
		table.toggleAllRowsExpanded = (expanded) => {
			if (expanded != null ? expanded : !table.getIsAllRowsExpanded()) table.setExpanded(true);
			else table.setExpanded({});
		};
		table.resetExpanded = (defaultState) => {
			var _table$initialState$e, _table$initialState;
			table.setExpanded(defaultState ? {} : (_table$initialState$e = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.expanded) != null ? _table$initialState$e : {});
		};
		table.getCanSomeRowsExpand = () => {
			return table.getPrePaginationRowModel().flatRows.some((row) => row.getCanExpand());
		};
		table.getToggleAllRowsExpandedHandler = () => {
			return (e) => {
				e.persist == null || e.persist();
				table.toggleAllRowsExpanded();
			};
		};
		table.getIsSomeRowsExpanded = () => {
			const expanded = table.getState().expanded;
			return expanded === true || Object.values(expanded).some(Boolean);
		};
		table.getIsAllRowsExpanded = () => {
			const expanded = table.getState().expanded;
			if (typeof expanded === "boolean") return expanded === true;
			if (!Object.keys(expanded).length) return false;
			if (table.getRowModel().flatRows.some((row) => !row.getIsExpanded())) return false;
			return true;
		};
		table.getExpandedDepth = () => {
			let maxDepth = 0;
			(table.getState().expanded === true ? Object.keys(table.getRowModel().rowsById) : Object.keys(table.getState().expanded)).forEach((id) => {
				const splitId = id.split(".");
				maxDepth = Math.max(maxDepth, splitId.length);
			});
			return maxDepth;
		};
		table.getPreExpandedRowModel = () => table.getSortedRowModel();
		table.getExpandedRowModel = () => {
			if (!table._getExpandedRowModel && table.options.getExpandedRowModel) table._getExpandedRowModel = table.options.getExpandedRowModel(table);
			if (table.options.manualExpanding || !table._getExpandedRowModel) return table.getPreExpandedRowModel();
			return table._getExpandedRowModel();
		};
	},
	createRow: (row, table) => {
		row.toggleExpanded = (expanded) => {
			table.setExpanded((old) => {
				var _expanded;
				const exists = old === true ? true : !!(old != null && old[row.id]);
				let oldExpanded = {};
				if (old === true) Object.keys(table.getRowModel().rowsById).forEach((rowId) => {
					oldExpanded[rowId] = true;
				});
				else oldExpanded = old;
				expanded = (_expanded = expanded) != null ? _expanded : !exists;
				if (!exists && expanded) return {
					...oldExpanded,
					[row.id]: true
				};
				if (exists && !expanded) {
					const { [row.id]: _, ...rest } = oldExpanded;
					return rest;
				}
				return old;
			});
		};
		row.getIsExpanded = () => {
			var _table$options$getIsR;
			const expanded = table.getState().expanded;
			return !!((_table$options$getIsR = table.options.getIsRowExpanded == null ? void 0 : table.options.getIsRowExpanded(row)) != null ? _table$options$getIsR : expanded === true || (expanded == null ? void 0 : expanded[row.id]));
		};
		row.getCanExpand = () => {
			var _table$options$getRow, _table$options$enable, _row$subRows;
			return (_table$options$getRow = table.options.getRowCanExpand == null ? void 0 : table.options.getRowCanExpand(row)) != null ? _table$options$getRow : ((_table$options$enable = table.options.enableExpanding) != null ? _table$options$enable : true) && !!((_row$subRows = row.subRows) != null && _row$subRows.length);
		};
		row.getIsAllParentsExpanded = () => {
			let isFullyExpanded = true;
			let currentRow = row;
			while (isFullyExpanded && currentRow.parentId) {
				currentRow = table.getRow(currentRow.parentId, true);
				isFullyExpanded = currentRow.getIsExpanded();
			}
			return isFullyExpanded;
		};
		row.getToggleExpandedHandler = () => {
			const canExpand = row.getCanExpand();
			return () => {
				if (!canExpand) return;
				row.toggleExpanded();
			};
		};
	}
};
var defaultPageIndex = 0;
var defaultPageSize = 10;
var getDefaultPaginationState = () => ({
	pageIndex: defaultPageIndex,
	pageSize: defaultPageSize
});
var RowPagination = {
	getInitialState: (state) => {
		return {
			...state,
			pagination: {
				...getDefaultPaginationState(),
				...state == null ? void 0 : state.pagination
			}
		};
	},
	getDefaultOptions: (table) => {
		return { onPaginationChange: makeStateUpdater("pagination", table) };
	},
	createTable: (table) => {
		let registered = false;
		let queued = false;
		table._autoResetPageIndex = () => {
			var _ref, _table$options$autoRe;
			if (!registered) {
				table._queue(() => {
					registered = true;
				});
				return;
			}
			if ((_ref = (_table$options$autoRe = table.options.autoResetAll) != null ? _table$options$autoRe : table.options.autoResetPageIndex) != null ? _ref : !table.options.manualPagination) {
				if (queued) return;
				queued = true;
				table._queue(() => {
					table.resetPageIndex();
					queued = false;
				});
			}
		};
		table.setPagination = (updater) => {
			const safeUpdater = (old) => {
				return functionalUpdate(updater, old);
			};
			return table.options.onPaginationChange == null ? void 0 : table.options.onPaginationChange(safeUpdater);
		};
		table.resetPagination = (defaultState) => {
			var _table$initialState$p;
			table.setPagination(defaultState ? getDefaultPaginationState() : (_table$initialState$p = table.initialState.pagination) != null ? _table$initialState$p : getDefaultPaginationState());
		};
		table.setPageIndex = (updater) => {
			table.setPagination((old) => {
				let pageIndex = functionalUpdate(updater, old.pageIndex);
				const maxPageIndex = typeof table.options.pageCount === "undefined" || table.options.pageCount === -1 ? Number.MAX_SAFE_INTEGER : table.options.pageCount - 1;
				pageIndex = Math.max(0, Math.min(pageIndex, maxPageIndex));
				return {
					...old,
					pageIndex
				};
			});
		};
		table.resetPageIndex = (defaultState) => {
			var _table$initialState$p2, _table$initialState;
			table.setPageIndex(defaultState ? defaultPageIndex : (_table$initialState$p2 = (_table$initialState = table.initialState) == null || (_table$initialState = _table$initialState.pagination) == null ? void 0 : _table$initialState.pageIndex) != null ? _table$initialState$p2 : defaultPageIndex);
		};
		table.resetPageSize = (defaultState) => {
			var _table$initialState$p3, _table$initialState2;
			table.setPageSize(defaultState ? defaultPageSize : (_table$initialState$p3 = (_table$initialState2 = table.initialState) == null || (_table$initialState2 = _table$initialState2.pagination) == null ? void 0 : _table$initialState2.pageSize) != null ? _table$initialState$p3 : defaultPageSize);
		};
		table.setPageSize = (updater) => {
			table.setPagination((old) => {
				const pageSize = Math.max(1, functionalUpdate(updater, old.pageSize));
				const topRowIndex = old.pageSize * old.pageIndex;
				const pageIndex = Math.floor(topRowIndex / pageSize);
				return {
					...old,
					pageIndex,
					pageSize
				};
			});
		};
		table.setPageCount = (updater) => table.setPagination((old) => {
			var _table$options$pageCo;
			let newPageCount = functionalUpdate(updater, (_table$options$pageCo = table.options.pageCount) != null ? _table$options$pageCo : -1);
			if (typeof newPageCount === "number") newPageCount = Math.max(-1, newPageCount);
			return {
				...old,
				pageCount: newPageCount
			};
		});
		table.getPageOptions = memo$1(() => [table.getPageCount()], (pageCount) => {
			let pageOptions = [];
			if (pageCount && pageCount > 0) pageOptions = [...new Array(pageCount)].fill(null).map((_, i) => i);
			return pageOptions;
		}, getMemoOptions(table.options, "debugTable", "getPageOptions"));
		table.getCanPreviousPage = () => table.getState().pagination.pageIndex > 0;
		table.getCanNextPage = () => {
			const { pageIndex } = table.getState().pagination;
			const pageCount = table.getPageCount();
			if (pageCount === -1) return true;
			if (pageCount === 0) return false;
			return pageIndex < pageCount - 1;
		};
		table.previousPage = () => {
			return table.setPageIndex((old) => old - 1);
		};
		table.nextPage = () => {
			return table.setPageIndex((old) => {
				return old + 1;
			});
		};
		table.firstPage = () => {
			return table.setPageIndex(0);
		};
		table.lastPage = () => {
			return table.setPageIndex(table.getPageCount() - 1);
		};
		table.getPrePaginationRowModel = () => table.getExpandedRowModel();
		table.getPaginationRowModel = () => {
			if (!table._getPaginationRowModel && table.options.getPaginationRowModel) table._getPaginationRowModel = table.options.getPaginationRowModel(table);
			if (table.options.manualPagination || !table._getPaginationRowModel) return table.getPrePaginationRowModel();
			return table._getPaginationRowModel();
		};
		table.getPageCount = () => {
			var _table$options$pageCo2;
			return (_table$options$pageCo2 = table.options.pageCount) != null ? _table$options$pageCo2 : Math.ceil(table.getRowCount() / table.getState().pagination.pageSize);
		};
		table.getRowCount = () => {
			var _table$options$rowCou;
			return (_table$options$rowCou = table.options.rowCount) != null ? _table$options$rowCou : table.getPrePaginationRowModel().rows.length;
		};
	}
};
var getDefaultRowPinningState = () => ({
	top: [],
	bottom: []
});
var RowPinning = {
	getInitialState: (state) => {
		return {
			rowPinning: getDefaultRowPinningState(),
			...state
		};
	},
	getDefaultOptions: (table) => {
		return { onRowPinningChange: makeStateUpdater("rowPinning", table) };
	},
	createRow: (row, table) => {
		row.pin = (position, includeLeafRows, includeParentRows) => {
			const leafRowIds = includeLeafRows ? row.getLeafRows().map((_ref) => {
				let { id } = _ref;
				return id;
			}) : [];
			const parentRowIds = includeParentRows ? row.getParentRows().map((_ref2) => {
				let { id } = _ref2;
				return id;
			}) : [];
			const rowIds = new Set([
				...parentRowIds,
				row.id,
				...leafRowIds
			]);
			table.setRowPinning((old) => {
				var _old$top3, _old$bottom3;
				if (position === "bottom") {
					var _old$top, _old$bottom;
					return {
						top: ((_old$top = old == null ? void 0 : old.top) != null ? _old$top : []).filter((d) => !(rowIds != null && rowIds.has(d))),
						bottom: [...((_old$bottom = old == null ? void 0 : old.bottom) != null ? _old$bottom : []).filter((d) => !(rowIds != null && rowIds.has(d))), ...Array.from(rowIds)]
					};
				}
				if (position === "top") {
					var _old$top2, _old$bottom2;
					return {
						top: [...((_old$top2 = old == null ? void 0 : old.top) != null ? _old$top2 : []).filter((d) => !(rowIds != null && rowIds.has(d))), ...Array.from(rowIds)],
						bottom: ((_old$bottom2 = old == null ? void 0 : old.bottom) != null ? _old$bottom2 : []).filter((d) => !(rowIds != null && rowIds.has(d)))
					};
				}
				return {
					top: ((_old$top3 = old == null ? void 0 : old.top) != null ? _old$top3 : []).filter((d) => !(rowIds != null && rowIds.has(d))),
					bottom: ((_old$bottom3 = old == null ? void 0 : old.bottom) != null ? _old$bottom3 : []).filter((d) => !(rowIds != null && rowIds.has(d)))
				};
			});
		};
		row.getCanPin = () => {
			var _ref3;
			const { enableRowPinning, enablePinning } = table.options;
			if (typeof enableRowPinning === "function") return enableRowPinning(row);
			return (_ref3 = enableRowPinning != null ? enableRowPinning : enablePinning) != null ? _ref3 : true;
		};
		row.getIsPinned = () => {
			const rowIds = [row.id];
			const { top, bottom } = table.getState().rowPinning;
			const isTop = rowIds.some((d) => top == null ? void 0 : top.includes(d));
			const isBottom = rowIds.some((d) => bottom == null ? void 0 : bottom.includes(d));
			return isTop ? "top" : isBottom ? "bottom" : false;
		};
		row.getPinnedIndex = () => {
			var _ref4, _visiblePinnedRowIds$;
			const position = row.getIsPinned();
			if (!position) return -1;
			const visiblePinnedRowIds = (_ref4 = position === "top" ? table.getTopRows() : table.getBottomRows()) == null ? void 0 : _ref4.map((_ref5) => {
				let { id } = _ref5;
				return id;
			});
			return (_visiblePinnedRowIds$ = visiblePinnedRowIds == null ? void 0 : visiblePinnedRowIds.indexOf(row.id)) != null ? _visiblePinnedRowIds$ : -1;
		};
	},
	createTable: (table) => {
		table.setRowPinning = (updater) => table.options.onRowPinningChange == null ? void 0 : table.options.onRowPinningChange(updater);
		table.resetRowPinning = (defaultState) => {
			var _table$initialState$r, _table$initialState;
			return table.setRowPinning(defaultState ? getDefaultRowPinningState() : (_table$initialState$r = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.rowPinning) != null ? _table$initialState$r : getDefaultRowPinningState());
		};
		table.getIsSomeRowsPinned = (position) => {
			var _pinningState$positio;
			const pinningState = table.getState().rowPinning;
			if (!position) {
				var _pinningState$top, _pinningState$bottom;
				return Boolean(((_pinningState$top = pinningState.top) == null ? void 0 : _pinningState$top.length) || ((_pinningState$bottom = pinningState.bottom) == null ? void 0 : _pinningState$bottom.length));
			}
			return Boolean((_pinningState$positio = pinningState[position]) == null ? void 0 : _pinningState$positio.length);
		};
		table._getPinnedRows = (visibleRows, pinnedRowIds, position) => {
			var _table$options$keepPi;
			return (((_table$options$keepPi = table.options.keepPinnedRows) != null ? _table$options$keepPi : true) ? (pinnedRowIds != null ? pinnedRowIds : []).map((rowId) => {
				const row = table.getRow(rowId, true);
				return row.getIsAllParentsExpanded() ? row : null;
			}) : (pinnedRowIds != null ? pinnedRowIds : []).map((rowId) => visibleRows.find((row) => row.id === rowId))).filter(Boolean).map((d) => ({
				...d,
				position
			}));
		};
		table.getTopRows = memo$1(() => [table.getRowModel().rows, table.getState().rowPinning.top], (allRows, topPinnedRowIds) => table._getPinnedRows(allRows, topPinnedRowIds, "top"), getMemoOptions(table.options, "debugRows", "getTopRows"));
		table.getBottomRows = memo$1(() => [table.getRowModel().rows, table.getState().rowPinning.bottom], (allRows, bottomPinnedRowIds) => table._getPinnedRows(allRows, bottomPinnedRowIds, "bottom"), getMemoOptions(table.options, "debugRows", "getBottomRows"));
		table.getCenterRows = memo$1(() => [
			table.getRowModel().rows,
			table.getState().rowPinning.top,
			table.getState().rowPinning.bottom
		], (allRows, top, bottom) => {
			const topAndBottom = new Set([...top != null ? top : [], ...bottom != null ? bottom : []]);
			return allRows.filter((d) => !topAndBottom.has(d.id));
		}, getMemoOptions(table.options, "debugRows", "getCenterRows"));
	}
};
var RowSelection = {
	getInitialState: (state) => {
		return {
			rowSelection: {},
			...state
		};
	},
	getDefaultOptions: (table) => {
		return {
			onRowSelectionChange: makeStateUpdater("rowSelection", table),
			enableRowSelection: true,
			enableMultiRowSelection: true,
			enableSubRowSelection: true
		};
	},
	createTable: (table) => {
		table.setRowSelection = (updater) => table.options.onRowSelectionChange == null ? void 0 : table.options.onRowSelectionChange(updater);
		table.resetRowSelection = (defaultState) => {
			var _table$initialState$r;
			return table.setRowSelection(defaultState ? {} : (_table$initialState$r = table.initialState.rowSelection) != null ? _table$initialState$r : {});
		};
		table.toggleAllRowsSelected = (value) => {
			table.setRowSelection((old) => {
				value = typeof value !== "undefined" ? value : !table.getIsAllRowsSelected();
				const rowSelection = { ...old };
				const preGroupedFlatRows = table.getPreGroupedRowModel().flatRows;
				if (value) preGroupedFlatRows.forEach((row) => {
					if (!row.getCanSelect()) return;
					rowSelection[row.id] = true;
				});
				else preGroupedFlatRows.forEach((row) => {
					delete rowSelection[row.id];
				});
				return rowSelection;
			});
		};
		table.toggleAllPageRowsSelected = (value) => table.setRowSelection((old) => {
			const resolvedValue = typeof value !== "undefined" ? value : !table.getIsAllPageRowsSelected();
			const rowSelection = { ...old };
			table.getRowModel().rows.forEach((row) => {
				mutateRowIsSelected(rowSelection, row.id, resolvedValue, true, table);
			});
			return rowSelection;
		});
		table.getPreSelectedRowModel = () => table.getCoreRowModel();
		table.getSelectedRowModel = memo$1(() => [table.getState().rowSelection, table.getCoreRowModel()], (rowSelection, rowModel) => {
			if (!Object.keys(rowSelection).length) return {
				rows: [],
				flatRows: [],
				rowsById: {}
			};
			return selectRowsFn(table, rowModel);
		}, getMemoOptions(table.options, "debugTable", "getSelectedRowModel"));
		table.getFilteredSelectedRowModel = memo$1(() => [table.getState().rowSelection, table.getFilteredRowModel()], (rowSelection, rowModel) => {
			if (!Object.keys(rowSelection).length) return {
				rows: [],
				flatRows: [],
				rowsById: {}
			};
			return selectRowsFn(table, rowModel);
		}, getMemoOptions(table.options, "debugTable", "getFilteredSelectedRowModel"));
		table.getGroupedSelectedRowModel = memo$1(() => [table.getState().rowSelection, table.getSortedRowModel()], (rowSelection, rowModel) => {
			if (!Object.keys(rowSelection).length) return {
				rows: [],
				flatRows: [],
				rowsById: {}
			};
			return selectRowsFn(table, rowModel);
		}, getMemoOptions(table.options, "debugTable", "getGroupedSelectedRowModel"));
		table.getIsAllRowsSelected = () => {
			const preGroupedFlatRows = table.getFilteredRowModel().flatRows;
			const { rowSelection } = table.getState();
			let isAllRowsSelected = Boolean(preGroupedFlatRows.length && Object.keys(rowSelection).length);
			if (isAllRowsSelected) {
				if (preGroupedFlatRows.some((row) => row.getCanSelect() && !rowSelection[row.id])) isAllRowsSelected = false;
			}
			return isAllRowsSelected;
		};
		table.getIsAllPageRowsSelected = () => {
			const paginationFlatRows = table.getPaginationRowModel().flatRows.filter((row) => row.getCanSelect());
			const { rowSelection } = table.getState();
			let isAllPageRowsSelected = !!paginationFlatRows.length;
			if (isAllPageRowsSelected && paginationFlatRows.some((row) => !rowSelection[row.id])) isAllPageRowsSelected = false;
			return isAllPageRowsSelected;
		};
		table.getIsSomeRowsSelected = () => {
			var _table$getState$rowSe;
			const totalSelected = Object.keys((_table$getState$rowSe = table.getState().rowSelection) != null ? _table$getState$rowSe : {}).length;
			return totalSelected > 0 && totalSelected < table.getFilteredRowModel().flatRows.length;
		};
		table.getIsSomePageRowsSelected = () => {
			const paginationFlatRows = table.getPaginationRowModel().flatRows;
			return table.getIsAllPageRowsSelected() ? false : paginationFlatRows.filter((row) => row.getCanSelect()).some((d) => d.getIsSelected() || d.getIsSomeSelected());
		};
		table.getToggleAllRowsSelectedHandler = () => {
			return (e) => {
				table.toggleAllRowsSelected(e.target.checked);
			};
		};
		table.getToggleAllPageRowsSelectedHandler = () => {
			return (e) => {
				table.toggleAllPageRowsSelected(e.target.checked);
			};
		};
	},
	createRow: (row, table) => {
		row.toggleSelected = (value, opts) => {
			const isSelected = row.getIsSelected();
			table.setRowSelection((old) => {
				var _opts$selectChildren;
				value = typeof value !== "undefined" ? value : !isSelected;
				if (row.getCanSelect() && isSelected === value) return old;
				const selectedRowIds = { ...old };
				mutateRowIsSelected(selectedRowIds, row.id, value, (_opts$selectChildren = opts == null ? void 0 : opts.selectChildren) != null ? _opts$selectChildren : true, table);
				return selectedRowIds;
			});
		};
		row.getIsSelected = () => {
			const { rowSelection } = table.getState();
			return isRowSelected(row, rowSelection);
		};
		row.getIsSomeSelected = () => {
			const { rowSelection } = table.getState();
			return isSubRowSelected(row, rowSelection) === "some";
		};
		row.getIsAllSubRowsSelected = () => {
			const { rowSelection } = table.getState();
			return isSubRowSelected(row, rowSelection) === "all";
		};
		row.getCanSelect = () => {
			var _table$options$enable;
			if (typeof table.options.enableRowSelection === "function") return table.options.enableRowSelection(row);
			return (_table$options$enable = table.options.enableRowSelection) != null ? _table$options$enable : true;
		};
		row.getCanSelectSubRows = () => {
			var _table$options$enable2;
			if (typeof table.options.enableSubRowSelection === "function") return table.options.enableSubRowSelection(row);
			return (_table$options$enable2 = table.options.enableSubRowSelection) != null ? _table$options$enable2 : true;
		};
		row.getCanMultiSelect = () => {
			var _table$options$enable3;
			if (typeof table.options.enableMultiRowSelection === "function") return table.options.enableMultiRowSelection(row);
			return (_table$options$enable3 = table.options.enableMultiRowSelection) != null ? _table$options$enable3 : true;
		};
		row.getToggleSelectedHandler = () => {
			const canSelect = row.getCanSelect();
			return (e) => {
				var _target;
				if (!canSelect) return;
				row.toggleSelected((_target = e.target) == null ? void 0 : _target.checked);
			};
		};
	}
};
var mutateRowIsSelected = (selectedRowIds, id, value, includeChildren, table) => {
	var _row$subRows;
	const row = table.getRow(id, true);
	if (value) {
		if (!row.getCanMultiSelect()) Object.keys(selectedRowIds).forEach((key) => delete selectedRowIds[key]);
		if (row.getCanSelect()) selectedRowIds[id] = true;
	} else delete selectedRowIds[id];
	if (includeChildren && (_row$subRows = row.subRows) != null && _row$subRows.length && row.getCanSelectSubRows()) row.subRows.forEach((row) => mutateRowIsSelected(selectedRowIds, row.id, value, includeChildren, table));
};
function selectRowsFn(table, rowModel) {
	const rowSelection = table.getState().rowSelection;
	const newSelectedFlatRows = [];
	const newSelectedRowsById = {};
	const recurseRows = function(rows, depth) {
		return rows.map((row) => {
			var _row$subRows2;
			const isSelected = isRowSelected(row, rowSelection);
			if (isSelected) {
				newSelectedFlatRows.push(row);
				newSelectedRowsById[row.id] = row;
			}
			if ((_row$subRows2 = row.subRows) != null && _row$subRows2.length) row = {
				...row,
				subRows: recurseRows(row.subRows)
			};
			if (isSelected) return row;
		}).filter(Boolean);
	};
	return {
		rows: recurseRows(rowModel.rows),
		flatRows: newSelectedFlatRows,
		rowsById: newSelectedRowsById
	};
}
function isRowSelected(row, selection) {
	var _selection$row$id;
	return (_selection$row$id = selection[row.id]) != null ? _selection$row$id : false;
}
function isSubRowSelected(row, selection, table) {
	var _row$subRows3;
	if (!((_row$subRows3 = row.subRows) != null && _row$subRows3.length)) return false;
	let allChildrenSelected = true;
	let someSelected = false;
	row.subRows.forEach((subRow) => {
		if (someSelected && !allChildrenSelected) return;
		if (subRow.getCanSelect()) if (isRowSelected(subRow, selection)) someSelected = true;
		else allChildrenSelected = false;
		if (subRow.subRows && subRow.subRows.length) {
			const subRowChildrenSelected = isSubRowSelected(subRow, selection);
			if (subRowChildrenSelected === "all") someSelected = true;
			else if (subRowChildrenSelected === "some") {
				someSelected = true;
				allChildrenSelected = false;
			} else allChildrenSelected = false;
		}
	});
	return allChildrenSelected ? "all" : someSelected ? "some" : false;
}
var reSplitAlphaNumeric = /([0-9]+)/gm;
var alphanumeric = (rowA, rowB, columnId) => {
	return compareAlphanumeric(toString(rowA.getValue(columnId)).toLowerCase(), toString(rowB.getValue(columnId)).toLowerCase());
};
var alphanumericCaseSensitive = (rowA, rowB, columnId) => {
	return compareAlphanumeric(toString(rowA.getValue(columnId)), toString(rowB.getValue(columnId)));
};
var text = (rowA, rowB, columnId) => {
	return compareBasic(toString(rowA.getValue(columnId)).toLowerCase(), toString(rowB.getValue(columnId)).toLowerCase());
};
var textCaseSensitive = (rowA, rowB, columnId) => {
	return compareBasic(toString(rowA.getValue(columnId)), toString(rowB.getValue(columnId)));
};
var datetime = (rowA, rowB, columnId) => {
	const a = rowA.getValue(columnId);
	const b = rowB.getValue(columnId);
	return a > b ? 1 : a < b ? -1 : 0;
};
var basic = (rowA, rowB, columnId) => {
	return compareBasic(rowA.getValue(columnId), rowB.getValue(columnId));
};
function compareBasic(a, b) {
	return a === b ? 0 : a > b ? 1 : -1;
}
function toString(a) {
	if (typeof a === "number") {
		if (isNaN(a) || a === Infinity || a === -Infinity) return "";
		return String(a);
	}
	if (typeof a === "string") return a;
	return "";
}
function compareAlphanumeric(aStr, bStr) {
	const a = aStr.split(reSplitAlphaNumeric).filter(Boolean);
	const b = bStr.split(reSplitAlphaNumeric).filter(Boolean);
	while (a.length && b.length) {
		const aa = a.shift();
		const bb = b.shift();
		const an = parseInt(aa, 10);
		const bn = parseInt(bb, 10);
		const combo = [an, bn].sort();
		if (isNaN(combo[0])) {
			if (aa > bb) return 1;
			if (bb > aa) return -1;
			continue;
		}
		if (isNaN(combo[1])) return isNaN(an) ? -1 : 1;
		if (an > bn) return 1;
		if (bn > an) return -1;
	}
	return a.length - b.length;
}
var sortingFns = {
	alphanumeric,
	alphanumericCaseSensitive,
	text,
	textCaseSensitive,
	datetime,
	basic
};
var builtInFeatures = [
	Headers,
	ColumnVisibility,
	ColumnOrdering,
	ColumnPinning,
	ColumnFaceting,
	ColumnFiltering,
	GlobalFaceting,
	GlobalFiltering,
	{
		getInitialState: (state) => {
			return {
				sorting: [],
				...state
			};
		},
		getDefaultColumnDef: () => {
			return {
				sortingFn: "auto",
				sortUndefined: 1
			};
		},
		getDefaultOptions: (table) => {
			return {
				onSortingChange: makeStateUpdater("sorting", table),
				isMultiSortEvent: (e) => {
					return e.shiftKey;
				}
			};
		},
		createColumn: (column, table) => {
			column.getAutoSortingFn = () => {
				const firstRows = table.getFilteredRowModel().flatRows.slice(10);
				let isString = false;
				for (const row of firstRows) {
					const value = row == null ? void 0 : row.getValue(column.id);
					if (Object.prototype.toString.call(value) === "[object Date]") return sortingFns.datetime;
					if (typeof value === "string") {
						isString = true;
						if (value.split(reSplitAlphaNumeric).length > 1) return sortingFns.alphanumeric;
					}
				}
				if (isString) return sortingFns.text;
				return sortingFns.basic;
			};
			column.getAutoSortDir = () => {
				const firstRow = table.getFilteredRowModel().flatRows[0];
				if (typeof (firstRow == null ? void 0 : firstRow.getValue(column.id)) === "string") return "asc";
				return "desc";
			};
			column.getSortingFn = () => {
				var _table$options$sortin, _table$options$sortin2;
				if (!column) throw new Error();
				return isFunction(column.columnDef.sortingFn) ? column.columnDef.sortingFn : column.columnDef.sortingFn === "auto" ? column.getAutoSortingFn() : (_table$options$sortin = (_table$options$sortin2 = table.options.sortingFns) == null ? void 0 : _table$options$sortin2[column.columnDef.sortingFn]) != null ? _table$options$sortin : sortingFns[column.columnDef.sortingFn];
			};
			column.toggleSorting = (desc, multi) => {
				const nextSortingOrder = column.getNextSortingOrder();
				const hasManualValue = typeof desc !== "undefined" && desc !== null;
				table.setSorting((old) => {
					const existingSorting = old == null ? void 0 : old.find((d) => d.id === column.id);
					const existingIndex = old == null ? void 0 : old.findIndex((d) => d.id === column.id);
					let newSorting = [];
					let sortAction;
					let nextDesc = hasManualValue ? desc : nextSortingOrder === "desc";
					if (old != null && old.length && column.getCanMultiSort() && multi) if (existingSorting) sortAction = "toggle";
					else sortAction = "add";
					else if (old != null && old.length && existingIndex !== old.length - 1) sortAction = "replace";
					else if (existingSorting) sortAction = "toggle";
					else sortAction = "replace";
					if (sortAction === "toggle") {
						if (!hasManualValue) {
							if (!nextSortingOrder) sortAction = "remove";
						}
					}
					if (sortAction === "add") {
						var _table$options$maxMul;
						newSorting = [...old, {
							id: column.id,
							desc: nextDesc
						}];
						newSorting.splice(0, newSorting.length - ((_table$options$maxMul = table.options.maxMultiSortColCount) != null ? _table$options$maxMul : Number.MAX_SAFE_INTEGER));
					} else if (sortAction === "toggle") newSorting = old.map((d) => {
						if (d.id === column.id) return {
							...d,
							desc: nextDesc
						};
						return d;
					});
					else if (sortAction === "remove") newSorting = old.filter((d) => d.id !== column.id);
					else newSorting = [{
						id: column.id,
						desc: nextDesc
					}];
					return newSorting;
				});
			};
			column.getFirstSortDir = () => {
				var _ref, _column$columnDef$sor;
				return ((_ref = (_column$columnDef$sor = column.columnDef.sortDescFirst) != null ? _column$columnDef$sor : table.options.sortDescFirst) != null ? _ref : column.getAutoSortDir() === "desc") ? "desc" : "asc";
			};
			column.getNextSortingOrder = (multi) => {
				var _table$options$enable, _table$options$enable2;
				const firstSortDirection = column.getFirstSortDir();
				const isSorted = column.getIsSorted();
				if (!isSorted) return firstSortDirection;
				if (isSorted !== firstSortDirection && ((_table$options$enable = table.options.enableSortingRemoval) != null ? _table$options$enable : true) && (multi ? (_table$options$enable2 = table.options.enableMultiRemove) != null ? _table$options$enable2 : true : true)) return false;
				return isSorted === "desc" ? "asc" : "desc";
			};
			column.getCanSort = () => {
				var _column$columnDef$ena, _table$options$enable3;
				return ((_column$columnDef$ena = column.columnDef.enableSorting) != null ? _column$columnDef$ena : true) && ((_table$options$enable3 = table.options.enableSorting) != null ? _table$options$enable3 : true) && !!column.accessorFn;
			};
			column.getCanMultiSort = () => {
				var _ref2, _column$columnDef$ena2;
				return (_ref2 = (_column$columnDef$ena2 = column.columnDef.enableMultiSort) != null ? _column$columnDef$ena2 : table.options.enableMultiSort) != null ? _ref2 : !!column.accessorFn;
			};
			column.getIsSorted = () => {
				var _table$getState$sorti;
				const columnSort = (_table$getState$sorti = table.getState().sorting) == null ? void 0 : _table$getState$sorti.find((d) => d.id === column.id);
				return !columnSort ? false : columnSort.desc ? "desc" : "asc";
			};
			column.getSortIndex = () => {
				var _table$getState$sorti2, _table$getState$sorti3;
				return (_table$getState$sorti2 = (_table$getState$sorti3 = table.getState().sorting) == null ? void 0 : _table$getState$sorti3.findIndex((d) => d.id === column.id)) != null ? _table$getState$sorti2 : -1;
			};
			column.clearSorting = () => {
				table.setSorting((old) => old != null && old.length ? old.filter((d) => d.id !== column.id) : []);
			};
			column.getToggleSortingHandler = () => {
				const canSort = column.getCanSort();
				return (e) => {
					if (!canSort) return;
					e.persist == null || e.persist();
					column.toggleSorting == null || column.toggleSorting(void 0, column.getCanMultiSort() ? table.options.isMultiSortEvent == null ? void 0 : table.options.isMultiSortEvent(e) : false);
				};
			};
		},
		createTable: (table) => {
			table.setSorting = (updater) => table.options.onSortingChange == null ? void 0 : table.options.onSortingChange(updater);
			table.resetSorting = (defaultState) => {
				var _table$initialState$s, _table$initialState;
				table.setSorting(defaultState ? [] : (_table$initialState$s = (_table$initialState = table.initialState) == null ? void 0 : _table$initialState.sorting) != null ? _table$initialState$s : []);
			};
			table.getPreSortedRowModel = () => table.getGroupedRowModel();
			table.getSortedRowModel = () => {
				if (!table._getSortedRowModel && table.options.getSortedRowModel) table._getSortedRowModel = table.options.getSortedRowModel(table);
				if (table.options.manualSorting || !table._getSortedRowModel) return table.getPreSortedRowModel();
				return table._getSortedRowModel();
			};
		}
	},
	ColumnGrouping,
	RowExpanding,
	RowPagination,
	RowPinning,
	RowSelection,
	ColumnSizing
];
function createTable(options) {
	var _options$_features, _options$initialState;
	if (process.env.NODE_ENV !== "production" && (options.debugAll || options.debugTable)) console.info("Creating Table Instance...");
	const _features = [...builtInFeatures, ...(_options$_features = options._features) != null ? _options$_features : []];
	let table = { _features };
	const defaultOptions = table._features.reduce((obj, feature) => {
		return Object.assign(obj, feature.getDefaultOptions == null ? void 0 : feature.getDefaultOptions(table));
	}, {});
	const mergeOptions = (options) => {
		if (table.options.mergeOptions) return table.options.mergeOptions(defaultOptions, options);
		return {
			...defaultOptions,
			...options
		};
	};
	let initialState = { ...(_options$initialState = options.initialState) != null ? _options$initialState : {} };
	table._features.forEach((feature) => {
		var _feature$getInitialSt;
		initialState = (_feature$getInitialSt = feature.getInitialState == null ? void 0 : feature.getInitialState(initialState)) != null ? _feature$getInitialSt : initialState;
	});
	const queued = [];
	let queuedTimeout = false;
	const coreInstance = {
		_features,
		options: {
			...defaultOptions,
			...options
		},
		initialState,
		_queue: (cb) => {
			queued.push(cb);
			if (!queuedTimeout) {
				queuedTimeout = true;
				Promise.resolve().then(() => {
					while (queued.length) queued.shift()();
					queuedTimeout = false;
				}).catch((error) => setTimeout(() => {
					throw error;
				}));
			}
		},
		reset: () => {
			table.setState(table.initialState);
		},
		setOptions: (updater) => {
			table.options = mergeOptions(functionalUpdate(updater, table.options));
		},
		getState: () => {
			return table.options.state;
		},
		setState: (updater) => {
			table.options.onStateChange == null || table.options.onStateChange(updater);
		},
		_getRowId: (row, index, parent) => {
			var _table$options$getRow;
			return (_table$options$getRow = table.options.getRowId == null ? void 0 : table.options.getRowId(row, index, parent)) != null ? _table$options$getRow : `${parent ? [parent.id, index].join(".") : index}`;
		},
		getCoreRowModel: () => {
			if (!table._getCoreRowModel) table._getCoreRowModel = table.options.getCoreRowModel(table);
			return table._getCoreRowModel();
		},
		getRowModel: () => {
			return table.getPaginationRowModel();
		},
		getRow: (id, searchAll) => {
			let row = (searchAll ? table.getPrePaginationRowModel() : table.getRowModel()).rowsById[id];
			if (!row) {
				row = table.getCoreRowModel().rowsById[id];
				if (!row) {
					if (process.env.NODE_ENV !== "production") throw new Error(`getRow could not find row with ID: ${id}`);
					throw new Error();
				}
			}
			return row;
		},
		_getDefaultColumnDef: memo$1(() => [table.options.defaultColumn], (defaultColumn) => {
			var _defaultColumn;
			defaultColumn = (_defaultColumn = defaultColumn) != null ? _defaultColumn : {};
			return {
				header: (props) => {
					const resolvedColumnDef = props.header.column.columnDef;
					if (resolvedColumnDef.accessorKey) return resolvedColumnDef.accessorKey;
					if (resolvedColumnDef.accessorFn) return resolvedColumnDef.id;
					return null;
				},
				cell: (props) => {
					var _props$renderValue$to, _props$renderValue;
					return (_props$renderValue$to = (_props$renderValue = props.renderValue()) == null || _props$renderValue.toString == null ? void 0 : _props$renderValue.toString()) != null ? _props$renderValue$to : null;
				},
				...table._features.reduce((obj, feature) => {
					return Object.assign(obj, feature.getDefaultColumnDef == null ? void 0 : feature.getDefaultColumnDef());
				}, {}),
				...defaultColumn
			};
		}, getMemoOptions(options, "debugColumns", "_getDefaultColumnDef")),
		_getColumnDefs: () => table.options.columns,
		getAllColumns: memo$1(() => [table._getColumnDefs()], (columnDefs) => {
			const recurseColumns = function(columnDefs, parent, depth) {
				if (depth === void 0) depth = 0;
				return columnDefs.map((columnDef) => {
					const column = createColumn(table, columnDef, depth, parent);
					const groupingColumnDef = columnDef;
					column.columns = groupingColumnDef.columns ? recurseColumns(groupingColumnDef.columns, column, depth + 1) : [];
					return column;
				});
			};
			return recurseColumns(columnDefs);
		}, getMemoOptions(options, "debugColumns", "getAllColumns")),
		getAllFlatColumns: memo$1(() => [table.getAllColumns()], (allColumns) => {
			return allColumns.flatMap((column) => {
				return column.getFlatColumns();
			});
		}, getMemoOptions(options, "debugColumns", "getAllFlatColumns")),
		_getAllFlatColumnsById: memo$1(() => [table.getAllFlatColumns()], (flatColumns) => {
			return flatColumns.reduce((acc, column) => {
				acc[column.id] = column;
				return acc;
			}, {});
		}, getMemoOptions(options, "debugColumns", "getAllFlatColumnsById")),
		getAllLeafColumns: memo$1(() => [table.getAllColumns(), table._getOrderColumnsFn()], (allColumns, orderColumns) => {
			return orderColumns(allColumns.flatMap((column) => column.getLeafColumns()));
		}, getMemoOptions(options, "debugColumns", "getAllLeafColumns")),
		getColumn: (columnId) => {
			const column = table._getAllFlatColumnsById()[columnId];
			if (process.env.NODE_ENV !== "production" && !column) console.error(`[Table] Column with id '${columnId}' does not exist.`);
			return column;
		}
	};
	Object.assign(table, coreInstance);
	for (let index = 0; index < table._features.length; index++) {
		const feature = table._features[index];
		feature == null || feature.createTable == null || feature.createTable(table);
	}
	return table;
}
function getCoreRowModel() {
	return (table) => memo$1(() => [table.options.data], (data) => {
		const rowModel = {
			rows: [],
			flatRows: [],
			rowsById: {}
		};
		const accessRows = function(originalRows, depth, parentRow) {
			if (depth === void 0) depth = 0;
			const rows = [];
			for (let i = 0; i < originalRows.length; i++) {
				const row = createRow(table, table._getRowId(originalRows[i], i, parentRow), originalRows[i], i, depth, void 0, parentRow == null ? void 0 : parentRow.id);
				rowModel.flatRows.push(row);
				rowModel.rowsById[row.id] = row;
				rows.push(row);
				if (table.options.getSubRows) {
					var _row$originalSubRows;
					row.originalSubRows = table.options.getSubRows(originalRows[i], i);
					if ((_row$originalSubRows = row.originalSubRows) != null && _row$originalSubRows.length) row.subRows = accessRows(row.originalSubRows, depth + 1, row);
				}
			}
			return rows;
		};
		rowModel.rows = accessRows(data);
		return rowModel;
	}, getMemoOptions(table.options, "debugTable", "getRowModel", () => table._autoResetPageIndex()));
}
//#endregion
//#region ../../node_modules/@tanstack/react-table/build/lib/index.mjs
/**
* react-table
*
* Copyright (c) TanStack
*
* This source code is licensed under the MIT license found in the
* LICENSE.md file in the root directory of this source tree.
*
* @license MIT
*/
/**
* If rendering headers, cells, or footers with custom markup, use flexRender instead of `cell.getValue()` or `cell.renderValue()`.
*/
function flexRender(Comp, props) {
	return !Comp ? null : isReactComponent(Comp) ? /*#__PURE__*/ React$1.createElement(Comp, props) : Comp;
}
function isReactComponent(component) {
	return isClassComponent(component) || typeof component === "function" || isExoticComponent(component);
}
function isClassComponent(component) {
	return typeof component === "function" && (() => {
		const proto = Object.getPrototypeOf(component);
		return proto.prototype && proto.prototype.isReactComponent;
	})();
}
function isExoticComponent(component) {
	return typeof component === "object" && typeof component.$$typeof === "symbol" && ["react.memo", "react.forward_ref"].includes(component.$$typeof.description);
}
function useReactTable(options) {
	const resolvedOptions = {
		state: {},
		onStateChange: () => {},
		renderFallbackValue: null,
		...options
	};
	const [tableRef] = React$1.useState(() => ({ current: createTable(resolvedOptions) }));
	const [state, setState] = React$1.useState(() => tableRef.current.initialState);
	tableRef.current.setOptions((prev) => ({
		...prev,
		...options,
		state: {
			...state,
			...options.state
		},
		onStateChange: (updater) => {
			setState(updater);
			options.onStateChange == null || options.onStateChange(updater);
		}
	}));
	return tableRef.current;
}
//#endregion
//#region ../../resources/scripts/components/ui/styles.ts
/** Tighter spacing for an `Empty` that sits inside a card, table or dialog. */
var emptyCompactClass = "gap-4 md:p-8";
//#endregion
//#region ../../resources/scripts/components/elements/table/DataTable.tsx
var ariaSort = (table, column) => {
	const ids = column.columnDef.meta?.sortColumnIds;
	const direction = ids ? ids.map((id) => table.getColumn(id)?.getIsSorted()).find(Boolean) ?? false : column.getIsSorted();
	if (direction === "asc") return "ascending";
	if (direction === "desc") return "descending";
};
function DataTable({ table, emptyState, className, tableClassName, isFetching = false }) {
	const rows = table.getRowModel().rows;
	return /* @__PURE__ */ jsx("div", {
		"aria-busy": isFetching,
		className: cn("@container overflow-hidden rounded-sm border border-border bg-card", className),
		children: rows.length === 0 ? /* @__PURE__ */ jsx("div", {
			className: cn("flex transition-opacity", isFetching && "opacity-55"),
			children: isString$1(emptyState) ? /* @__PURE__ */ jsx(Empty, {
				className: emptyCompactClass,
				children: /* @__PURE__ */ jsx(EmptyDescription, { children: emptyState })
			}) : emptyState
		}) : /* @__PURE__ */ jsx("div", {
			className: "overflow-x-auto scrollbar-thin scrollbar-thumb-(--scrollbar-thumb)",
			children: /* @__PURE__ */ jsxs("table", {
				className: cn("w-full border-collapse text-left text-sm", tableClassName),
				children: [/* @__PURE__ */ jsx("thead", {
					className: "border-b border-border bg-muted/70",
					children: table.getHeaderGroups().map((headerGroup) => /* @__PURE__ */ jsx("tr", { children: headerGroup.headers.map((header) => /* @__PURE__ */ jsx("th", {
						scope: "col",
						"aria-sort": ariaSort(table, header.column),
						className: cn("h-10 whitespace-nowrap px-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground", header.column.columnDef.meta?.headerClassName),
						children: header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())
					}, header.id)) }, headerGroup.id))
				}), /* @__PURE__ */ jsx("tbody", {
					className: cn("divide-y divide-border transition-opacity", isFetching && "opacity-55"),
					children: rows.map((row) => /* @__PURE__ */ jsx("tr", {
						className: "transition-colors hover:bg-muted/35",
						children: row.getVisibleCells().map((cell) => /* @__PURE__ */ jsx("td", {
							className: cn("px-3 py-2.5 align-middle text-foreground", cell.column.columnDef.meta?.cellClassName),
							children: flexRender(cell.column.columnDef.cell, cell.getContext())
						}, cell.id))
					}, row.id))
				})]
			})
		})
	});
}
//#endregion
//#region ../../resources/scripts/components/elements/Pagination.tsx
var Block = ({ className, ...props }) => /* @__PURE__ */ jsx(ButtonWithVariants, {
	type: "button",
	className: cn("p-0 w-10 h-10 not-last-of-type:mr-2", className),
	...props
});
var normalizeGeneratedPagination = (pagination) => ({
	total: pagination.total,
	count: pagination.count,
	perPage: pagination.per_page,
	currentPage: pagination.current_page,
	totalPages: pagination.total_pages
});
function Pagination({ data, onPageSelect, children }) {
	const items = data.data;
	const pagination = normalizeGeneratedPagination(data.meta.pagination);
	const isFirstPage = pagination.currentPage === 1;
	const isLastPage = pagination.currentPage >= pagination.totalPages;
	const pages = [];
	const start = Math.max(pagination.currentPage - 2, 1);
	const end = Math.min(pagination.totalPages, pagination.currentPage + 5);
	for (let i = start; i <= end; i++) pages.push(i);
	return /* @__PURE__ */ jsxs(Fragment, { children: [children({
		items,
		isFirstPage,
		isLastPage
	}), pages.length > 1 && /* @__PURE__ */ jsxs("div", {
		className: "mt-4 flex justify-center",
		children: [
			pages[0] > 1 && !isFirstPage && /* @__PURE__ */ jsx(Block, {
				isSecondary: true,
				color: "primary",
				onClick: () => onPageSelect(1),
				children: /* @__PURE__ */ jsx(Icon, { icon: ChevronsLeft })
			}),
			pages.map((page) => /* @__PURE__ */ jsx(Block, {
				isSecondary: pagination.currentPage !== page,
				color: "primary",
				onClick: () => onPageSelect(page),
				children: page
			}, `block_page_${page}`)),
			pages[4] < pagination.totalPages && !isLastPage && /* @__PURE__ */ jsx(Block, {
				isSecondary: true,
				color: "primary",
				onClick: () => onPageSelect(pagination.totalPages),
				children: /* @__PURE__ */ jsx(Icon, { icon: ChevronsRight })
			})
		]
	})] });
}
//#endregion
//#region ../../resources/scripts/sdk/ui.tsx
function Table({ rows, columns, keyOf, ...props }) {
	return /* @__PURE__ */ jsx(DataTable, {
		table: useReactTable({
			data: useMemo(() => [...rows], [rows]),
			columns: useMemo(() => columns.map((column) => ({
				id: column.id,
				header: () => column.label,
				cell: ({ row }) => column.cell(row.original)
			})), [columns]),
			getRowId: keyOf,
			getCoreRowModel: getCoreRowModel()
		}),
		...props
	});
}
function Tooltip(props) {
	return /* @__PURE__ */ jsx(Tooltip$1, { ...props });
}
//#endregion
//#region ../../resources/scripts/api/server/startup/queries.ts
var serverStartupInput = (uuid) => ({ path: { server_uuid: uuid } });
var retryStartupRead = retryUnlessClientError(3);
var serverStartupQueryOptions$1 = (uuid) => ({
	...clientGetStartupConfigurationOptions(serverStartupInput(uuid)),
	retry: retryStartupRead
});
var useSetSelectedDockerImage = (uuid) => {
	const updateCurrentServer = useUpdateCurrentServer();
	return useMutation({
		...clientSetServerDockerImageMutation(),
		scope: { id: `server-startup:${uuid}` },
		onSuccess: (_data, variables) => {
			updateCurrentServer((server) => ({
				...server,
				attributes: {
					...server.attributes,
					docker_image: variables.body.docker_image
				}
			}));
			toast$1.success("Docker image updated");
		},
		onError: (error) => notifyHttpError(error, "Unable to update Docker image")
	});
};
var useUpdateStartupVariable = (uuid) => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientUpdateStartupVariableMutation(),
		scope: { id: `server-startup:${uuid}` },
		onSuccess: async (resource, variables) => {
			await queryClient.cancelQueries({ queryKey: clientGetStartupConfigurationQueryKey(serverStartupInput(variables.path.server_uuid)) });
			queryClient.setQueryData(clientGetStartupConfigurationQueryKey(serverStartupInput(variables.path.server_uuid)), (data) => {
				const updated = updateListItems(data, (item) => item.attributes.env_variable === resource.attributes.env_variable, () => resource);
				if (!updated?.meta) return updated;
				return {
					...updated,
					meta: {
						...updated.meta,
						startup_command: resource.meta?.startup_command ?? updated.meta.startup_command
					}
				};
			});
		},
		onError: (error) => notifyHttpError(error, "Unable to update startup variable")
	});
};
//#endregion
//#region ../../resources/scripts/api/server/backups/queries.ts
var serverBackupsInput = (uuid, page) => ({
	path: { server_uuid: uuid },
	query: { page }
});
var createServerBackupInput = (uuid, values) => ({
	path: { server_uuid: uuid },
	body: {
		name: values.name,
		ignored: values.ignored,
		is_locked: values.isLocked
	}
});
var serverBackupsQueryOptions$1 = (uuid, page = 1) => clientListServerBackupsOptions(serverBackupsInput(uuid, page));
var useCreateServerBackup$1 = () => {
	const queryClient = useQueryClient();
	return useMutation({
		...clientCreateServerBackupMutation(),
		onSuccess: async (backup, { path }) => {
			await queryClient.invalidateQueries({ queryKey: clientListServerBackupsQueryKey({ path: { server_uuid: path.server_uuid } }) });
			toast$1.success("Backup started", { description: `${backup.attributes.name} is being created.` });
		},
		onError: (error) => notifyHttpError(error, "Unable to create backup")
	});
};
//#endregion
//#region ../../resources/scripts/api/account/servers/queries.ts
var serverResourcesInput = (uuid) => ({ path: { server_uuid: uuid } });
var serverResourceUsageQueryOptions = (uuid) => ({
	...clientGetServerResourcesOptions(serverResourcesInput(uuid)),
	retry: false
});
/** Wings refreshes usage at most every 20 seconds. */
var serverResourceUsageRefetchInterval = (query) => query.state.data?.attributes.is_suspended ? false : 3e4;
var clampLines = (lines) => Math.min(Math.max(Math.trunc(lines) || 1, 1), 100);
var serverLogsInput = (uuid, lines) => ({
	path: { server_uuid: uuid },
	query: { lines: clampLines(lines) }
});
var serverLogsQueryOptions$1 = (uuid, lines = 100) => clientGetServerLogsOptions(serverLogsInput(uuid, lines));
//#endregion
//#region ../../resources/scripts/api/server/queryDomains.ts
var domainKeys = {
	files: (id) => clientListFilesQueryKey({ path: { server_uuid: id } }),
	fileContent: (id) => {
		const [{ query: _query, ...key }] = clientGetFileContentsQueryKey({
			path: { server_uuid: id },
			query: { file: "" }
		});
		return [key];
	},
	startup: (id) => clientGetStartupConfigurationQueryKey({ path: { server_uuid: id } }),
	backups: (id) => clientListServerBackupsQueryKey({ path: { server_uuid: id } }),
	resources: (id) => clientGetServerResourcesQueryKey({ path: { server_uuid: id } })
};
function serverDomainQueryFilters(id, domain) {
	return domain === "server" ? serverQueryFilters(id) : { queryKey: domainKeys[domain](id) };
}
//#endregion
//#region ../../resources/scripts/sdk/queryOptions.ts
function publicQueryOptions(options, retry) {
	const fetch = options.queryFn;
	if (!fetch || fetch === skipToken) throw new Error("The panel query has no fetcher.");
	const queryFn = (context) => fetch({
		...context,
		queryKey: options.queryKey
	});
	const { queryKey } = queryOptions({
		queryKey: options.queryKey,
		queryFn
	});
	return retry === void 0 ? {
		queryKey,
		queryFn
	} : {
		queryKey,
		queryFn,
		retry
	};
}
//#endregion
//#region ../../resources/scripts/sdk/server.ts
function serverQueryOptions(id) {
	return publicQueryOptions(serverQueryOptions$1(id));
}
function serverFilesQueryOptions(id, directory) {
	return publicQueryOptions(serverFilesQueryOptions$1(id, directory));
}
function serverFileContentQueryOptions(id, file) {
	return publicQueryOptions(serverFileContentQueryOptions$1(id, file));
}
function serverStartupQueryOptions(id) {
	const options = serverStartupQueryOptions$1(id);
	return publicQueryOptions(options, options.retry);
}
function serverBackupsQueryOptions(id, page = 1) {
	return publicQueryOptions(serverBackupsQueryOptions$1(id, page));
}
/** Power state and resource usage, in the cache entry the dashboard's server cards poll. */
function serverResourcesQueryOptions(id) {
	const options = serverResourceUsageQueryOptions(id);
	return publicQueryOptions(options, options.retry);
}
/** Recent console output, oldest first; `lines` is clamped to 1-100 and needs `websocket.connect`. */
function serverLogsQueryOptions(id, lines) {
	return publicQueryOptions(serverLogsQueryOptions$1(id, lines));
}
function useServerFiles(id, directory, select) {
	return useQuery({
		...serverFilesQueryOptions(id, directory),
		enabled: !!id,
		select
	});
}
function useServerFileContent(id, file) {
	return useQuery({
		...serverFileContentQueryOptions(id, file),
		enabled: !!id && !!file
	});
}
function useServerStartup(id, select) {
	return useQuery({
		...serverStartupQueryOptions(id),
		enabled: !!id,
		select
	});
}
function useServerBackups(id, page = 1, select) {
	return useQuery({
		...serverBackupsQueryOptions(id, page),
		enabled: !!id,
		select
	});
}
/** Polls like the dashboard. Inside the server area, the "stats" and "status" websocket events are live. */
function useServerResources(id, select) {
	return useQuery({
		...serverResourcesQueryOptions(id),
		enabled: !!id,
		select,
		refetchInterval: serverResourceUsageRefetchInterval
	});
}
/** Return this promise from extension mutation callbacks to await the host's refetches. */
async function invalidateServerData(id, domains) {
	await Promise.all([...new Set(domains)].map((domain) => queryClient.invalidateQueries(serverDomainQueryFilters(id, domain))));
}
//#endregion
//#region ../../resources/scripts/api/server/power/queries.ts
var sendPowerActionInput = (uuid, signal) => ({
	path: { server_uuid: uuid },
	body: { signal }
});
var sendServerCommandInput = (uuid, command) => ({
	path: { server_uuid: uuid },
	body: { command }
});
var useSendPowerAction = () => useMutation({
	...clientSendPowerActionMutation(),
	onError: (error) => notifyHttpError(error, "Unable to send power action")
});
var useSendServerCommand$1 = () => useMutation({
	...clientSendServerCommandMutation(),
	onError: (error) => notifyHttpError(error, "Unable to send command")
});
//#endregion
//#region ../../resources/scripts/sdk/mutations.ts
/** A panel mutation that takes the SDK's input and resolves with nothing. */
function voidMutation(mutation, toVariables) {
	return {
		...mutation,
		mutateAsync: async (input) => {
			await mutation.mutateAsync(toVariables(input));
		},
		data: void 0
	};
}
function useCreateServerDirectory(uuid) {
	return voidMutation(useCreateDirectory(), ({ directory, name }) => createDirectoryInput(uuid, directory, name));
}
function useRenameServerFiles(uuid) {
	return voidMutation(useRenameFiles(), ({ directory, files }) => renameFilesInput(uuid, directory, files));
}
function useDeleteServerFiles(uuid) {
	return voidMutation(useDeleteFiles(), ({ directory, files }) => deleteFilesInput(uuid, directory, files));
}
function useWriteServerFile(uuid) {
	return voidMutation(useSaveFileContent(), ({ file, content }) => writeFileContentsInput(uuid, file, content));
}
function useUpdateServerStartupVariable(uuid) {
	const mutation = useUpdateStartupVariable(uuid);
	return {
		...mutation,
		mutateAsync: ({ key, value }) => mutation.mutateAsync({
			path: { server_uuid: uuid },
			body: {
				key,
				value
			}
		})
	};
}
function useSetServerDockerImage(uuid) {
	return voidMutation(useSetSelectedDockerImage(uuid), ({ image }) => ({
		path: { server_uuid: uuid },
		body: { docker_image: image }
	}));
}
function useCreateServerBackup(uuid) {
	const mutation = useCreateServerBackup$1();
	return {
		...mutation,
		mutateAsync: (values) => mutation.mutateAsync(createServerBackupInput(uuid, values))
	};
}
/** The API requires the control permission that matches the signal. */
function useSendServerPower(uuid) {
	return voidMutation(useSendPowerAction(), ({ signal }) => sendPowerActionInput(uuid, signal));
}
/** The API requires control.console and a running server. */
function useSendServerCommand(uuid) {
	return voidMutation(useSendServerCommand$1(), ({ command }) => sendServerCommandInput(uuid, command));
}
//#endregion
//#region ../../node_modules/react-i18next/dist/es/utils.js
var warn = (i18n, code, msg, rest) => {
	const args = [msg, {
		code,
		...rest || {}
	}];
	if (i18n?.services?.logger?.forward) return i18n.services.logger.forward(args, "warn", "react-i18next::", true);
	if (isString(args[0])) args[0] = `react-i18next:: ${args[0]}`;
	if (i18n?.services?.logger?.warn) i18n.services.logger.warn(...args);
	else if (console?.warn) console.warn(...args);
};
var alreadyWarned = {};
var warnOnce = (i18n, code, msg, rest) => {
	if (isString(msg) && alreadyWarned[msg]) return;
	if (isString(msg)) alreadyWarned[msg] = /* @__PURE__ */ new Date();
	warn(i18n, code, msg, rest);
};
var loadedClb = (i18n, cb) => () => {
	if (i18n.isInitialized) cb();
	else {
		const initialized = () => {
			setTimeout(() => {
				i18n.off("initialized", initialized);
			}, 0);
			cb();
		};
		i18n.on("initialized", initialized);
	}
};
var loadNamespaces = (i18n, ns, cb) => {
	i18n.loadNamespaces(ns, loadedClb(i18n, cb));
};
var loadLanguages = (i18n, lng, ns, cb) => {
	if (isString(ns)) ns = [ns];
	if (i18n.options.preload && i18n.options.preload.indexOf(lng) > -1) return loadNamespaces(i18n, ns, cb);
	ns.forEach((n) => {
		if (i18n.options.ns.indexOf(n) < 0) i18n.options.ns.push(n);
	});
	i18n.loadLanguages(lng, loadedClb(i18n, cb));
};
var hasLoadedNamespace = (ns, i18n, options = {}) => {
	if (!i18n.languages || !i18n.languages.length) {
		warnOnce(i18n, "NO_LANGUAGES", "i18n.languages were undefined or empty", { languages: i18n.languages });
		return true;
	}
	return i18n.hasLoadedNamespace(ns, {
		lng: options.lng,
		precheck: (i18nInstance, loadNotPending) => {
			if (options.bindI18n && options.bindI18n.indexOf("languageChanging") > -1 && i18nInstance.services.backendConnector.backend && i18nInstance.isLanguageChangingTo && !loadNotPending(i18nInstance.isLanguageChangingTo, ns)) return false;
		}
	});
};
var isString = (obj) => typeof obj === "string";
var isObject = (obj) => typeof obj === "object" && obj !== null;
//#endregion
//#region ../../node_modules/react-i18next/dist/es/unescape.js
var matchHtmlEntity = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g;
var htmlEntities = {
	"&amp;": "&",
	"&#38;": "&",
	"&lt;": "<",
	"&#60;": "<",
	"&gt;": ">",
	"&#62;": ">",
	"&apos;": "'",
	"&#39;": "'",
	"&quot;": "\"",
	"&#34;": "\"",
	"&nbsp;": " ",
	"&#160;": " ",
	"&copy;": "©",
	"&#169;": "©",
	"&reg;": "®",
	"&#174;": "®",
	"&hellip;": "…",
	"&#8230;": "…",
	"&#x2F;": "/",
	"&#47;": "/"
};
var unescapeHtmlEntity = (m) => htmlEntities[m];
var unescape = (text) => text.replace(matchHtmlEntity, unescapeHtmlEntity);
//#endregion
//#region ../../node_modules/react-i18next/dist/es/defaults.js
var defaultOptions = {
	bindI18n: "languageChanged",
	bindI18nStore: "",
	transEmptyNodeValue: "",
	transSupportBasicHtmlNodes: true,
	transWrapTextNodes: "",
	transKeepBasicHtmlNodesFor: [
		"br",
		"strong",
		"i",
		"p"
	],
	useSuspense: true,
	unescape,
	transDefaultProps: void 0
};
var getDefaults = () => defaultOptions;
//#endregion
//#region ../../node_modules/react-i18next/dist/es/i18nInstance.js
var i18nInstance;
var getI18n = () => i18nInstance;
//#endregion
//#region ../../node_modules/react-i18next/dist/es/context.js
var I18nContext = createContext();
var ReportNamespaces = class {
	constructor() {
		this.usedNamespaces = {};
	}
	addUsedNamespaces(namespaces) {
		namespaces.forEach((ns) => {
			if (!this.usedNamespaces[ns]) this.usedNamespaces[ns] = true;
		});
	}
	getUsedNamespaces() {
		return Object.keys(this.usedNamespaces);
	}
};
//#endregion
//#region builtin:esm-external-require-react
var require_builtin_esm_external_require_react = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = { ...React$1 };
}));
//#endregion
//#region ../../node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.production.js
/**
* @license React
* use-sync-external-store-shim.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_shim_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var React = require_builtin_esm_external_require_react();
	function is(x, y) {
		return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
	}
	var objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue;
	function useSyncExternalStore$2(subscribe, getSnapshot) {
		var value = getSnapshot(), _useState = useState({ inst: {
			value,
			getSnapshot
		} }), inst = _useState[0].inst, forceUpdate = _useState[1];
		useLayoutEffect(function() {
			inst.value = value;
			inst.getSnapshot = getSnapshot;
			checkIfSnapshotChanged(inst) && forceUpdate({ inst });
		}, [
			subscribe,
			value,
			getSnapshot
		]);
		useEffect(function() {
			checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			return subscribe(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			});
		}, [subscribe]);
		useDebugValue(value);
		return value;
	}
	function checkIfSnapshotChanged(inst) {
		var latestGetSnapshot = inst.getSnapshot;
		inst = inst.value;
		try {
			var nextValue = latestGetSnapshot();
			return !objectIs(inst, nextValue);
		} catch (error) {
			return !0;
		}
	}
	function useSyncExternalStore$1(subscribe, getSnapshot) {
		return getSnapshot();
	}
	var shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
	exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
}));
//#endregion
//#region ../../node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
/**
* @license React
* use-sync-external-store-shim.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_shim_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	"production" !== process.env.NODE_ENV && (function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		function useSyncExternalStore$2(subscribe, getSnapshot) {
			didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
			var value = getSnapshot();
			if (!didWarnUncachedGetSnapshot) {
				var cachedValue = getSnapshot();
				objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
			}
			cachedValue = useState({ inst: {
				value,
				getSnapshot
			} });
			var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
			useLayoutEffect(function() {
				inst.value = value;
				inst.getSnapshot = getSnapshot;
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			}, [
				subscribe,
				value,
				getSnapshot
			]);
			useEffect(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				return subscribe(function() {
					checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				});
			}, [subscribe]);
			useDebugValue(value);
			return value;
		}
		function checkIfSnapshotChanged(inst) {
			var latestGetSnapshot = inst.getSnapshot;
			inst = inst.value;
			try {
				var nextValue = latestGetSnapshot();
				return !objectIs(inst, nextValue);
			} catch (error) {
				return !0;
			}
		}
		function useSyncExternalStore$1(subscribe, getSnapshot) {
			return getSnapshot();
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_builtin_esm_external_require_react(), objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue, didWarnOld18Alpha = !1, didWarnUncachedGetSnapshot = !1, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
		exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region ../../node_modules/react-i18next/dist/es/useTranslation.js
var import_shim = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	if (process.env.NODE_ENV === "production") module.exports = require_use_sync_external_store_shim_production();
	else module.exports = require_use_sync_external_store_shim_development();
})))();
var notReadyT = (k, optsOrDefaultValue) => {
	if (isString(optsOrDefaultValue)) return optsOrDefaultValue;
	if (isObject(optsOrDefaultValue) && isString(optsOrDefaultValue.defaultValue)) return optsOrDefaultValue.defaultValue;
	if (typeof k === "function") return "";
	if (Array.isArray(k)) {
		const last = k[k.length - 1];
		return typeof last === "function" ? "" : last;
	}
	return k;
};
var notReadySnapshot = {
	t: notReadyT,
	ready: false
};
var dummySubscribe = () => () => {};
var useTranslation = (ns, props = {}) => {
	const { i18n: i18nFromProps } = props;
	const { i18n: i18nFromContext, defaultNS: defaultNSFromContext } = useContext(I18nContext) || {};
	const i18n = i18nFromProps || i18nFromContext || getI18n();
	if (i18n && !i18n.reportNamespaces) i18n.reportNamespaces = new ReportNamespaces();
	if (!i18n) warnOnce(i18n, "NO_I18NEXT_INSTANCE", "useTranslation: You will need to pass in an i18next instance by using initReactI18next");
	const i18nOptions = useMemo(() => ({
		...getDefaults(),
		...i18n?.options?.react,
		...props
	}), [i18n, props]);
	const { useSuspense, keyPrefix } = i18nOptions;
	const nsOrContext = ns || defaultNSFromContext || i18n?.options?.defaultNS;
	const unstableNamespaces = isString(nsOrContext) ? [nsOrContext] : nsOrContext || ["translation"];
	const namespaces = useMemo(() => unstableNamespaces, unstableNamespaces);
	i18n?.reportNamespaces?.addUsedNamespaces?.(namespaces);
	const revisionRef = useRef(0);
	const subscribe = useCallback((callback) => {
		if (!i18n) return dummySubscribe;
		const { bindI18n, bindI18nStore } = i18nOptions;
		const wrappedCallback = () => {
			revisionRef.current += 1;
			callback();
		};
		if (bindI18n) i18n.on(bindI18n, wrappedCallback);
		if (bindI18nStore) i18n.store.on(bindI18nStore, wrappedCallback);
		return () => {
			if (bindI18n) bindI18n.split(" ").forEach((e) => i18n.off(e, wrappedCallback));
			if (bindI18nStore) bindI18nStore.split(" ").forEach((e) => i18n.store.off(e, wrappedCallback));
		};
	}, [i18n, i18nOptions]);
	const snapshotRef = useRef();
	const getSnapshot = useCallback(() => {
		if (!i18n) return notReadySnapshot;
		const calculatedReady = !!(i18n.isInitialized || i18n.initializedStoreOnce) && namespaces.every((n) => hasLoadedNamespace(n, i18n, i18nOptions));
		const currentLng = props.lng || i18n.language;
		const currentRevision = revisionRef.current;
		const lastSnapshot = snapshotRef.current;
		if (lastSnapshot && lastSnapshot.ready === calculatedReady && lastSnapshot.lng === currentLng && lastSnapshot.keyPrefix === keyPrefix && lastSnapshot.revision === currentRevision) return lastSnapshot;
		const newSnapshot = {
			t: i18n.getFixedT(currentLng, i18nOptions.nsMode === "fallback" ? namespaces : namespaces[0], keyPrefix),
			ready: calculatedReady,
			lng: currentLng,
			keyPrefix,
			revision: currentRevision
		};
		snapshotRef.current = newSnapshot;
		return newSnapshot;
	}, [
		i18n,
		namespaces,
		keyPrefix,
		i18nOptions,
		props.lng
	]);
	const [loadCount, setLoadCount] = useState(0);
	const { t, ready } = (0, import_shim.useSyncExternalStore)(subscribe, getSnapshot, getSnapshot);
	useEffect(() => {
		if (i18n && !ready && !useSuspense) {
			const onLoaded = () => setLoadCount((c) => c + 1);
			if (props.lng) loadLanguages(i18n, props.lng, namespaces, onLoaded);
			else loadNamespaces(i18n, namespaces, onLoaded);
		}
	}, [
		i18n,
		props.lng,
		namespaces,
		ready,
		useSuspense,
		loadCount
	]);
	const finalI18n = i18n || {};
	const wrapperRef = useRef(null);
	const wrapperLangRef = useRef();
	const createI18nWrapper = (original) => {
		const descriptors = Object.getOwnPropertyDescriptors(original);
		if (descriptors.__original) delete descriptors.__original;
		const wrapper = Object.create(Object.getPrototypeOf(original), descriptors);
		if (!Object.prototype.hasOwnProperty.call(wrapper, "__original")) try {
			Object.defineProperty(wrapper, "__original", {
				value: original,
				writable: false,
				enumerable: false,
				configurable: false
			});
		} catch (_) {}
		return wrapper;
	};
	const ret = useMemo(() => {
		const original = finalI18n;
		const lang = original?.language;
		let i18nWrapper = original;
		if (original) if (wrapperRef.current && wrapperRef.current.__original === original) if (wrapperLangRef.current !== lang) {
			i18nWrapper = createI18nWrapper(original);
			wrapperRef.current = i18nWrapper;
			wrapperLangRef.current = lang;
		} else i18nWrapper = wrapperRef.current;
		else {
			i18nWrapper = createI18nWrapper(original);
			wrapperRef.current = i18nWrapper;
			wrapperLangRef.current = lang;
		}
		const effectiveT = !ready && !useSuspense ? (...args) => {
			warnOnce(i18n, "USE_T_BEFORE_READY", "useTranslation: t was called before ready. When using useSuspense: false, make sure to check the ready flag before using t.");
			return t(...args);
		} : t;
		const arr = [
			effectiveT,
			i18nWrapper,
			ready
		];
		arr.t = effectiveT;
		arr.i18n = i18nWrapper;
		arr.ready = ready;
		return arr;
	}, [
		t,
		finalI18n,
		ready,
		finalI18n.resolvedLanguage,
		finalI18n.language,
		finalI18n.languages
	]);
	if (i18n && useSuspense && !ready) throw new Promise((resolve) => {
		const onLoaded = () => resolve();
		if (props.lng) loadLanguages(i18n, props.lng, namespaces, onLoaded);
		else loadNamespaces(i18n, namespaces, onLoaded);
	});
	return ret;
};
//#endregion
//#region ../../resources/scripts/sdk/localization.ts
/** resources/lang/<locale>/<group>.php, registered with loadExtensionTranslations(). */
function useExtensionTranslation(group = "messages") {
	const mount = useContext(ExtensionContext);
	if (!mount) throw new Error("Extension translations require an extension mount.");
	if (!/^[a-z][a-z0-9_-]{0,63}$/.test(group)) throw new Error("Invalid extension translation group.");
	const { t, i18n, ready } = useTranslation(`ext-${mount.extensionId}::${group}`, { useSuspense: false });
	return {
		locale: i18n.language,
		ready,
		t: (key, values) => t(key, {
			...values,
			nsSeparator: false
		})
	};
}
//#endregion
//#region ../../resources/scripts/api/extensionProgress.ts
function extensionJobProgressQueryOptions(extension, job, serverUuid) {
	const queryFn = async ({ signal }) => {
		return (serverUuid ? await clientGetServerExtensionJobProgress({
			path: {
				extension,
				job,
				server_uuid: serverUuid
			},
			signal
		}) : await clientGetExtensionJobProgress({
			path: {
				extension,
				job
			},
			signal
		})).data.data;
	};
	return {
		queryKey: queryOptions({
			queryKey: [
				"extension-progress",
				extension,
				serverUuid ?? null,
				job
			],
			queryFn
		}).queryKey,
		queryFn
	};
}
//#endregion
//#region ../../resources/scripts/sdk/progress.ts
/** The key includes both the extension namespace and the subject. */
function extensionProgressQueryOptions(extension, job, serverUuid) {
	return publicQueryOptions(extensionJobProgressQueryOptions(extension, job, serverUuid));
}
/** Poll running jobs, stop terminal/expired jobs, and recover the latest snapshot on reconnect. */
function useExtensionJobProgress(job, options = {}) {
	const mount = useContext(ExtensionContext);
	if (!mount) throw new Error("Extension progress requires an extension mount.");
	return useQuery({
		...extensionProgressQueryOptions(mount.extensionId, job ?? "", options.serverUuid),
		enabled: !!job,
		staleTime: 0,
		refetchOnReconnect: "always",
		refetchInterval: (query) => query.state.error || query.state.data && query.state.data.status !== "running" ? false : 1500,
		retry: retryUnlessClientError(2)
	});
}
//#endregion
//#region ../../resources/scripts/lib/theme.ts
var THEME_CHANGE_EVENT = "pterodactyl:theme-change";
var listeners = /* @__PURE__ */ new Set();
var stopWatching;
var frame;
var isStylesheetNode = (node) => node instanceof HTMLStyleElement || node instanceof HTMLLinkElement && node.relList.contains("stylesheet");
var affectsTheme = (mutation) => {
	if (mutation.target === document.documentElement) return mutation.type === "attributes";
	if (mutation.type === "childList") return isStylesheetNode(mutation.target) || [...mutation.addedNodes, ...mutation.removedNodes].some((node) => isStylesheetNode(node));
	return isStylesheetNode(mutation.type === "characterData" ? mutation.target.parentNode : mutation.target);
};
var flush = () => {
	frame = void 0;
	for (const listener of listeners) listener();
};
var schedule = () => {
	frame ??= requestAnimationFrame(flush);
};
var watch = () => {
	const observer = new MutationObserver((mutations) => {
		if (mutations.some(affectsTheme)) schedule();
	});
	observer.observe(document.documentElement, { attributes: true });
	observer.observe(document.head, {
		attributes: true,
		characterData: true,
		childList: true,
		subtree: true
	});
	const onLoad = (event) => {
		if (event.target instanceof Node && isStylesheetNode(event.target)) schedule();
	};
	document.head.addEventListener("load", onLoad, true);
	window.addEventListener(THEME_CHANGE_EVENT, schedule);
	const scheme = window.matchMedia?.("(prefers-color-scheme: dark)");
	scheme?.addEventListener("change", schedule);
	return () => {
		observer.disconnect();
		document.head.removeEventListener("load", onLoad, true);
		window.removeEventListener(THEME_CHANGE_EVENT, schedule);
		scheme?.removeEventListener("change", schedule);
		if (frame !== void 0) {
			cancelAnimationFrame(frame);
			frame = void 0;
		}
	};
};
/** Calls `listener` at most once a frame; a hint, not a diff. */
var onThemeChange$1 = (listener) => {
	listeners.add(listener);
	stopWatching ??= watch();
	return () => {
		listeners.delete(listener);
		if (listeners.size === 0) {
			stopWatching?.();
			stopWatching = void 0;
		}
	};
};
var notifyThemeChange$1 = () => {
	window.dispatchEvent(new Event(THEME_CHANGE_EVENT));
};
var readThemeToken$1 = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
//#endregion
//#region ../../resources/scripts/sdk/theme.ts
/**
* Calls `listener`, at most once a frame, after a stylesheet or an `<html>` attribute changes.
* It is a hint, not a diff: compare the values you read. Returns the unsubscribe function.
*/
function onThemeChange(listener) {
	return onThemeChange$1(listener);
}
/** Report a token change the DOM cannot reveal (CSSOM rule edits, adopted stylesheets). */
function notifyThemeChange() {
	notifyThemeChange$1();
}
/** The current value of a token on `<html>`, e.g. `readThemeToken('--chart-1')`; '' when unset. */
function readThemeToken(name) {
	return readThemeToken$1(name);
}
//#endregion
//#region ../../resources/scripts/sdk/index.ts
function useCurrentUser() {
	return useCurrentUser$1();
}
function useSiteSettings() {
	return useSiteSettings$1();
}
function useCurrentServer(select) {
	return useCurrentServer$1(select);
}
function useCurrentServerPermissions() {
	return useCurrentServerPermissions$1();
}
/** Identity helper giving extension entrypoints full typing: `export default definePterodactylExtension({...})`. */
function definePterodactylExtension(definition) {
	return definition;
}
/** Like definePterodactylExtension, with `config` decoded by `parseConfig` and typed screen ids. */
function defineConfiguredExtension(parseConfig, definition) {
	return { setup: (context) => definition.setup({
		...context,
		config: parseConfig(context.config)
	}) };
}
/**
* Subscribes to a server websocket event while mounted under /server/$id.
* Only call from server screens, server slots, or components rendered under them.
*/
function useServerWebsocketEvent(event, callback) {
	useWebsocketEvent(event, useExtensionCallback(event, callback));
}
function useCurrentServerUuid() {
	return useCurrentServerUuid$1();
}
function useCurrentServerRequired(message = "This extension screen requires a server context.") {
	const server = useCurrentServer();
	if (!server) throw new Error(message);
	return server;
}
function useServerPermission(permission, matchAny = false) {
	const permissions = useCurrentServerPermissions();
	const matches = (Array.isArray(permission) ? permission : [permission]).map((item) => hasPermission(permissions, item));
	return matchAny ? matches.some(Boolean) : matches.every(Boolean);
}
//#endregion
export { Alert, ButtonWithVariants as Button, COMPONENT_NAMES, Can, Checkbox, ContentBox, ContextDropdownMenu, CopyOnClick, Dialog, DropdownMenuWithItems as DropdownMenu, DropdownMenuItem, EXTENSION_FORM_NAMES, Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle, Form, Icon, TextInput as Input, Label, NamedIcon, NotFound, NumberInput, PageContentBlock, Pagination, PanelLink, SLOT_NAMES, ScreenBlock, Select, ServerContentBlock, ServerError, SocketEvent, Spinner, Switch, Table, TextArea, TitledGreyBox, Tooltip, defineConfiguredExtension, definePterodactylExtension, extensionProgressQueryOptions, http, httpErrorToHuman, invalidateServerData, loadIconNames, notifyThemeChange, onThemeChange, queryClient, readThemeToken, resolvePanelDestination, serverBackupsQueryOptions, serverFileContentQueryOptions, serverFilesQueryOptions, serverLogsQueryOptions, serverQueryOptions, serverResourcesQueryOptions, serverStartupQueryOptions, toast, useAppForm, useCreateServerBackup, useCreateServerDirectory, useCurrentResource, useCurrentServer, useCurrentServerPermissions, useCurrentServerRequired, useCurrentServerUuid, useCurrentUser, useDeleteServerFiles, useExtensionCallback as useExtensionAction, useExtensionJobProgress, useExtensionTranslation, useFieldContext, useFormContext, useNavigationBlocker, useOpenLoginCheckpoint, usePanelLocation, usePanelNavigate, usePermissions, useRenameServerFiles, useSendServerCommand, useSendServerPower, useServerBackups, useServerFileContent, useServerFiles, useServerPermission, useServerResources, useServerStartup, useServerWebsocketEvent, useSetServerDockerImage, useSiteSettings, useUpdateServerStartupVariable, useWriteServerFile };

//# sourceMappingURL=sdk.js.map