import { a as createConfig, c as httpErrorToHuman, i as createClient, o as createClientConfig, r as client, s as http, t as queryClient } from "./queryClient-D97HhWup.js";
export { client, createClient, createClientConfig, createConfig, http, httpErrorToHuman, queryClient };
